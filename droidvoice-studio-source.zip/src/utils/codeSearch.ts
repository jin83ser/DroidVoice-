import { ProjectFile } from '../types';

export interface ProjectSearchMatch {
  id: string;
  filePath: string;
  fileName: string;
  line: number;
  column: number;
  lineText: string;
  matchStart: number;
  matchLength: number;
}

const LEADING_COMMAND_PATTERNS = [
  /^(?:пожалуйста\s+)?(?:найди|найти|поищи|поиск|искать|покажи|где\s+(?:находится|объявлена?|используется))\s+/i,
  /^(?:в\s+проекте|по\s+проекту|в\s+коде|по\s+коду)\s+/i,
  /^(?:функцию|функция|метод|класс|компонент|переменную|строку|строка|текст|слово)\s+/i,
  /^(?:find|search\s+for|search|locate|show)\s+/i,
  /^(?:function|method|class|string|variable)\s+/i,
];

export function normalizeVoiceSearchQuery(rawTranscript: string): string {
  let q = rawTranscript.trim().replace(/[«»"'`.,!?]+$/g, '').replace(/^[«»"'`]+/g, '');
  let changed = true;
  while (changed) {
    changed = false;
    for (const pattern of LEADING_COMMAND_PATTERNS) {
      const next = q.replace(pattern, '').trim();
      if (next !== q) {
        q = next;
        changed = true;
      }
    }
  }
  return q.trim();
}

export function searchProjectFiles(
  files: ProjectFile[],
  rawQuery: string
): ProjectSearchMatch[] {
  const query = rawQuery.trim();
  if (!query) return [];

  const lowerQuery = query.toLowerCase();
  const matches: ProjectSearchMatch[] = [];

  for (const file of files) {
    const fileName = file.path.split('/').pop() || file.path;
    const lines = file.content.split('\n');

    for (let i = 0; i < lines.length; i++) {
      const lineText = lines[i];
      const lowerLine = lineText.toLowerCase();
      let searchFrom = 0;

      while (searchFrom <= lowerLine.length - lowerQuery.length) {
        const idx = lowerLine.indexOf(lowerQuery, searchFrom);
        if (idx === -1) break;

        matches.push({
          id: `${file.path}:${i + 1}:${idx}`,
          filePath: file.path,
          fileName,
          line: i + 1,
          column: idx + 1,
          lineText,
          matchStart: idx,
          matchLength: query.length,
        });

        searchFrom = idx + Math.max(1, query.length);
        if (matches.length >= 200) return matches;
      }
    }
  }

  return matches;
}
