export type FileLanguage = 'kotlin' | 'xml' | 'gradle' | 'json' | 'markdown';

export interface ProjectFile {
  path: string;
  content: string;
  language: FileLanguage;
  modified?: boolean;
}

export interface ProjectConfig {
  projectName: string;
  applicationId: string;
  versionName: string;
  versionCode: number;
  minSdk: number;
  targetSdk: number;
  buildType: 'debug' | 'release';
}

export interface BuildLogEntry {
  id: string;
  timestamp: string;
  level: 'info' | 'task' | 'warn' | 'error' | 'success';
  source: 'gradle' | 'kotlinc' | 'aapt2' | 'dex' | 'signer' | 'system';
  message: string;
  file?: string;
  line?: number;
}

export interface BuildDiagnostic {
  file: string;
  line: number;
  column: number;
  severity: 'error' | 'warning';
  message: string;
}

export interface EmulatorWidgetSpec {
  id: string;
  type: 'text' | 'button' | 'card' | 'input' | 'switch' | 'progress' | 'listItem' | 'badge';
  label: string;
  sublabel?: string;
  stateKey?: string;
  action?: 'increment' | 'decrement' | 'toggle' | 'submit' | 'reset' | 'toast';
  toastMessage?: string;
  variant?: 'primary' | 'secondary' | 'outline';
  progressValue?: number;
}

export interface EmulatorScreenSpec {
  appTitle: string;
  packageName: string;
  accentHex: string;
  darkSurface: boolean;
  initialState: Record<string, string | number | boolean>;
  widgets: EmulatorWidgetSpec[];
  fabLabel?: string;
  fabAction?: 'increment' | 'reset' | 'toast';
  bottomTabs?: string[];
}

export interface BuildJob {
  id: string;
  status: 'idle' | 'queued' | 'compiling' | 'packaging' | 'success' | 'failed';
  progress: number;
  stage: string;
  buildType: 'debug' | 'release';
  startedAt: string;
  finishedAt?: string;
  durationMs?: number;
  apkFilename?: string;
  apkSizeBytes?: number;
  apkSha256?: string;
  logs: BuildLogEntry[];
  diagnostics: BuildDiagnostic[];
  uiPreview?: EmulatorScreenSpec;
}

export interface LogcatEntry {
  id: string;
  timestamp: string;
  pid: number;
  level: 'D' | 'I' | 'W' | 'E';
  tag: string;
  message: string;
}

export interface GitHubUser {
  login: string;
  name: string | null;
  avatar_url: string;
  html_url: string;
}

export interface GitHubRepoSummary {
  id: number;
  name: string;
  full_name: string;
  private: boolean;
  description: string | null;
  default_branch: string;
  updated_at: string;
  language: string | null;
  stargazers_count: number;
  html_url: string;
}

export interface GitHubCommitItem {
  sha: string;
  message: string;
  author: string;
  date: string;
  html_url: string;
}

export interface ConnectedRepo {
  owner: string;
  repo: string;
  branch: string;
  branches: string[];
  lastSyncedAt?: string;
  commits: GitHubCommitItem[];
}
