import { useCallback, useEffect, useRef, useState } from 'react';
import {
  BuildJob,
  BuildLogEntry,
  ConnectedRepo,
  EmulatorScreenSpec,
  FileLanguage,
  LogcatEntry,
  ProjectConfig,
  ProjectFile,
} from './types';
import { DEFAULT_PROJECT_CONFIG, STARTER_PROJECT_FILES } from './data/starterProject';
import { TopBar, WorkspaceSection } from './components/TopBar';
import { VoiceCoderBar } from './components/VoiceCoderBar';
import { FileExplorer } from './components/FileExplorer';
import { CodeEditorPane } from './components/CodeEditorPane';
import { BuildLogsPane } from './components/BuildLogsPane';
import { CloudEmulatorPane } from './components/CloudEmulatorPane';
import { GitHubWorkspace } from './components/GitHubWorkspace';
import { ProjectConfigModal } from './components/ProjectConfigModal';
import { ScreenTemplateModal } from './components/ScreenTemplateModal';
import { ResourcesTableEditor } from './components/ResourcesTableEditor';
import {
  DEFAULT_RESOURCE_XML,
  getResourceKindFromPath,
  RESOURCE_FILES_META,
  ResourceKind,
} from './utils/androidResources';

const INITIAL_EMULATOR_SPEC: EmulatorScreenSpec = {
  appTitle: 'DroidVoice Notes',
  packageName: 'com.droidvoice.notes',
  accentHex: '#10B981',
  darkSurface: true,
  initialState: {
    counter: 3,
    switch_sync: true,
    input_note: '',
  },
  widgets: [
    {
      id: 'card-summary',
      type: 'card',
      label: 'Активные заметки: 3',
      sublabel: 'Синхронизация через удаленный сервер сборки и GitHub',
      stateKey: 'counter',
    },
    {
      id: 'input-note',
      type: 'input',
      label: 'Текст заметки',
      stateKey: 'input_note',
    },
    {
      id: 'switch-sync',
      type: 'switch',
      label: 'Авто-синхронизация с GitHub',
      stateKey: 'switch_sync',
      action: 'toggle',
    },
    {
      id: 'btn-add',
      type: 'button',
      label: 'Добавить заметку',
      variant: 'primary',
      action: 'increment',
      toastMessage: 'Заметка добавлена',
    },
    {
      id: 'btn-reset',
      type: 'button',
      label: 'Сбросить счетчик',
      variant: 'outline',
      action: 'reset',
      toastMessage: 'Список заметок очищен',
    },
  ],
  fabLabel: '+',
  fabAction: 'increment',
};

const INITIAL_BUILD_JOB: BuildJob = {
  id: '',
  status: 'idle',
  progress: 0,
  stage: 'Готов к удаленной сборке',
  buildType: 'debug',
  startedAt: '',
  logs: [],
  diagnostics: [],
};

function inferLanguage(filePath: string): FileLanguage {
  if (filePath.endsWith('.kt')) return 'kotlin';
  if (filePath.endsWith('.xml')) return 'xml';
  if (filePath.endsWith('.kts') || filePath.endsWith('.gradle')) return 'gradle';
  if (filePath.endsWith('.json')) return 'json';
  return 'markdown';
}

export default function App() {
  const [isDark, setIsDark] = useState(true);
  const [activeSection, setActiveSection] = useState<WorkspaceSection>('ide');

  const [config, setConfig] = useState<ProjectConfig>(() => {
    try {
      const saved = localStorage.getItem('droidvoice_config');
      return saved ? (JSON.parse(saved) as ProjectConfig) : DEFAULT_PROJECT_CONFIG;
    } catch {
      return DEFAULT_PROJECT_CONFIG;
    }
  });

  const [files, setFiles] = useState<ProjectFile[]>(() => {
    try {
      const saved = localStorage.getItem('droidvoice_files');
      return saved ? (JSON.parse(saved) as ProjectFile[]) : STARTER_PROJECT_FILES;
    } catch {
      return STARTER_PROJECT_FILES;
    }
  });

  const [openTabs, setOpenTabs] = useState<string[]>(() => [
    STARTER_PROJECT_FILES[0].path,
    STARTER_PROJECT_FILES[3].path,
  ]);
  const [activeFilePath, setActiveFilePath] = useState<string>(STARTER_PROJECT_FILES[0].path);

  const [voiceHistory, setVoiceHistory] = useState<Array<{ path: string; previousContent: string }>>([]);
  const [isGeneratingCode, setIsGeneratingCode] = useState(false);
  const [lastVoiceSummary, setLastVoiceSummary] = useState<string | null>(null);

  const [buildJob, setBuildJob] = useState<BuildJob>(INITIAL_BUILD_JOB);
  const [screenSpec, setScreenSpec] = useState<EmulatorScreenSpec>(INITIAL_EMULATOR_SPEC);
  const [logcatEntries, setLogcatEntries] = useState<LogcatEntry[]>([
    {
      id: 'init-1',
      timestamp: '23:17:01.104',
      pid: 4128,
      level: 'I',
      tag: 'MainActivity',
      message: 'Инициализация DroidVoice Notes (Compose Runtime готов)',
    },
  ]);

  const [connectedRepo, setConnectedRepo] = useState<ConnectedRepo | null>(null);
  const [settingsModalOpen, setSettingsModalOpen] = useState(false);
  const [templateModalOpen, setTemplateModalOpen] = useState(false);
  const [editorViewMode, setEditorViewMode] = useState<'code' | 'table'>('code');
  const [jumpToLineRequest, setJumpToLineRequest] = useState<{
    file: string;
    line: number;
    nonce: number;
  } | null>(null);

  const eventSourceRef = useRef<EventSource | null>(null);

  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [isDark]);

  useEffect(() => {
    try {
      localStorage.setItem('droidvoice_files', JSON.stringify(files));
    } catch {
      // Ignore storage quota errors
    }
  }, [files]);

  useEffect(() => {
    try {
      localStorage.setItem('droidvoice_config', JSON.stringify(config));
    } catch {
      // Ignore
    }
  }, [config]);

  useEffect(() => {
    return () => {
      eventSourceRef.current?.close();
    };
  }, []);

  const emitLogcat = useCallback((level: LogcatEntry['level'], tag: string, message: string) => {
    const timestamp = new Date().toISOString().slice(11, 23);
    setLogcatEntries((prev) => [
      ...prev.slice(-150),
      {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        timestamp,
        pid: 4128,
        level,
        tag,
        message,
      },
    ]);
  }, []);

  const handleSelectFile = (path: string) => {
    setActiveFilePath(path);
    setOpenTabs((prev) => (prev.includes(path) ? prev : [...prev, path]));
    if (!getResourceKindFromPath(path)) {
      setEditorViewMode('code');
    }
  };

  const handleSelectResourceKind = (kind: ResourceKind) => {
    const existing = files.find((f) => getResourceKindFromPath(f.path) === kind);
    const targetPath =
      existing?.path ||
      RESOURCE_FILES_META.find((m) => m.kind === kind)!.defaultPath;

    if (!existing) {
      setFiles((prev) => [
        ...prev,
        {
          path: targetPath,
          content: DEFAULT_RESOURCE_XML[kind],
          language: 'xml',
          modified: true,
        },
      ]);
    }
    setActiveFilePath(targetPath);
    setOpenTabs((prev) => (prev.includes(targetPath) ? prev : [...prev, targetPath]));
    setEditorViewMode('table');
    setActiveSection('ide');
  };

  const handleCloseTab = (path: string) => {
    setOpenTabs((prev) => {
      const next = prev.filter((p) => p !== path);
      if (activeFilePath === path && next.length > 0) {
        setActiveFilePath(next[next.length - 1]);
      }
      return next;
    });
  };

  const handleChangeContent = (path: string, newContent: string) => {
    setFiles((prev) =>
      prev.map((f) => (f.path === path ? { ...f, content: newContent, modified: true } : f))
    );
  };

  const handleCreateFile = (path: string) => {
    if (files.some((f) => f.path === path)) {
      handleSelectFile(path);
      return;
    }
    const language = inferLanguage(path);
    const pkg = config.applicationId;
    const starter =
      language === 'kotlin'
        ? `package ${pkg}\n\nimport androidx.compose.material3.Text\nimport androidx.compose.runtime.Composable\n\n@Composable\nfun NewScreen() {\n    Text("Новый экран")\n}\n`
        : '';
    setFiles((prev) => [...prev, { path, content: starter, language, modified: true }]);
    handleSelectFile(path);
  };

  const handleDeleteFile = (path: string) => {
    setFiles((prev) => prev.filter((f) => f.path !== path));
    handleCloseTab(path);
  };

  const handleGenerateFromTemplate = (generatedFiles: ProjectFile[], templateTitle: string) => {
    setFiles((prev) => {
      const next = [...prev];
      for (const gf of generatedFiles) {
        const idx = next.findIndex((f) => f.path === gf.path);
        if (idx >= 0) {
          next[idx] = gf;
        } else {
          next.push(gf);
        }
      }
      return next;
    });

    const newPaths = generatedFiles.map((f) => f.path);
    setOpenTabs((prev) => {
      const merged = [...prev];
      for (const p of newPaths) {
        if (!merged.includes(p)) merged.push(p);
      }
      return merged;
    });

    const ktFile = generatedFiles.find((f) => f.language === 'kotlin') || generatedFiles[0];
    if (ktFile) {
      setActiveFilePath(ktFile.path);
    }

    setLastVoiceSummary(
      `Создан шаблон «${templateTitle}» (${generatedFiles.map((f) => f.path.split('/').pop()).join(', ')})`
    );
    emitLogcat(
      'I',
      'TemplateGen',
      `Сгенерирован экран «${templateTitle}»: ${generatedFiles.map((f) => f.path).join(' + ')}`
    );
  };

  const applyVoiceOrAiCommand = async (command: string, mode: 'edit' | 'fix' = 'edit') => {
    const targetFile = files.find((f) => f.path === activeFilePath) || files[0];
    if (!targetFile) return;

    setIsGeneratingCode(true);
    try {
      const resp = await fetch('/api/voice/to-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          command,
          activeFilePath: targetFile.path,
          activeFileContent: targetFile.content,
          mode,
          diagnostics: mode === 'fix' ? buildJob.diagnostics : undefined,
        }),
      });
      const data = (await resp.json()) as {
        summary?: string;
        updatedContent?: string;
        error?: string;
      };
      if (!resp.ok || !data.updatedContent) {
        throw new Error(data.error || 'Не удалось применить команду');
      }

      setVoiceHistory((prev) => [
        ...prev.slice(-9),
        { path: targetFile.path, previousContent: targetFile.content },
      ]);
      handleChangeContent(targetFile.path, data.updatedContent);
      setLastVoiceSummary(data.summary || 'Код обновлен');
      emitLogcat('I', 'VoiceCoder', `Обновлен файл ${targetFile.path.split('/').pop()}: ${data.summary}`);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Ошибка голосового генератора';
      setLastVoiceSummary(`Ошибка: ${msg}`);
    } finally {
      setIsGeneratingCode(false);
    }
  };

  const handleUndoVoice = () => {
    const last = voiceHistory[voiceHistory.length - 1];
    if (!last) return;
    setFiles((prev) =>
      prev.map((f) => (f.path === last.path ? { ...f, content: last.previousContent } : f))
    );
    setVoiceHistory((prev) => prev.slice(0, -1));
    setActiveFilePath(last.path);
    setLastVoiceSummary('Последнее изменение отменено');
  };

  const handleTriggerBuild = async () => {
    eventSourceRef.current?.close();

    setBuildJob({
      id: '',
      status: 'queued',
      progress: 3,
      stage: 'Отправка исходников на удаленный сервер сборки...',
      buildType: config.buildType,
      startedAt: new Date().toISOString(),
      logs: [],
      diagnostics: [],
    });

    try {
      const resp = await fetch('/api/build/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ config, files }),
      });
      const data = (await resp.json()) as { buildId?: string; error?: string };
      if (!resp.ok || !data.buildId) {
        throw new Error(data.error || 'Сервер сборки не ответил');
      }

      const buildId = data.buildId;
      const es = new EventSource(`/api/build/${buildId}/stream`);
      eventSourceRef.current = es;

      es.addEventListener('snapshot', (ev) => {
        const snap = JSON.parse((ev as MessageEvent).data) as BuildJob;
        setBuildJob(snap);
        if (snap.uiPreview) setScreenSpec(snap.uiPreview);
      });

      es.addEventListener('log', (ev) => {
        const entry = JSON.parse((ev as MessageEvent).data) as BuildLogEntry;
        setBuildJob((prev) => ({
          ...prev,
          logs: prev.logs.some((l) => l.id === entry.id) ? prev.logs : [...prev.logs, entry],
        }));
      });

      es.addEventListener('status', (ev) => {
        const st = JSON.parse((ev as MessageEvent).data) as Partial<BuildJob>;
        setBuildJob((prev) => ({ ...prev, ...st }));
        if (st.uiPreview) {
          setScreenSpec(st.uiPreview);
        }
        if (st.status === 'success') {
          emitLogcat(
            'I',
            'ActivityManager',
            `Установлен и запущен ${st.apkFilename || 'app.apk'} в облачном эмуляторе`
          );
        } else if (st.status === 'failed') {
          emitLogcat('E', 'BuildServer', st.stage || 'Ошибка сборки APK');
        }
      });

      es.addEventListener('done', () => {
        es.close();
      });

      es.onerror = () => {
        es.close();
      };
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Ошибка подключения к серверу сборки';
      setBuildJob((prev) => ({
        ...prev,
        status: 'failed',
        progress: 100,
        stage: msg,
      }));
    }
  };

  const handleJumpToDiagnostic = (file: string, line: number) => {
    setActiveSection('ide');
    handleSelectFile(file);
    setJumpToLineRequest({ file, line, nonce: Date.now() });
  };

  const handleImportFromGitHub = (importedFiles: ProjectFile[], repo: ConnectedRepo) => {
    setFiles(importedFiles);
    const firstKt = importedFiles.find((f) => f.language === 'kotlin') || importedFiles[0];
    if (firstKt) {
      setOpenTabs([firstKt.path]);
      setActiveFilePath(firstKt.path);
    }
    setConnectedRepo(repo);
    setActiveSection('ide');
    emitLogcat('I', 'GitHubSync', `Импортирован проект ${repo.owner}/${repo.repo} (${repo.branch})`);
  };

  const handleMarkAllSynced = (repo: ConnectedRepo) => {
    setFiles((prev) => prev.map((f) => ({ ...f, modified: false })));
    setConnectedRepo(repo);
    emitLogcat('I', 'GitHubSync', `Изменения отправлены в ${repo.owner}/${repo.repo}`);
  };

  const isBuilding =
    buildJob.status === 'queued' ||
    buildJob.status === 'compiling' ||
    buildJob.status === 'packaging';

  return (
    <div className="h-screen w-screen overflow-hidden flex flex-col bg-slate-50 dark:bg-[#0B0F17] text-slate-900 dark:text-slate-100">
      <TopBar
        activeSection={activeSection}
        onSelectSection={setActiveSection}
        onTriggerBuild={handleTriggerBuild}
        isBuilding={isBuilding}
      />

      {activeSection !== 'github' && (
        <VoiceCoderBar
          activeFilePath={activeFilePath}
          config={config}
          onChangeBuildType={(buildType) => setConfig((c) => ({ ...c, buildType }))}
          onApplyVoiceCommand={(cmd) => applyVoiceOrAiCommand(cmd, 'edit')}
          isGeneratingCode={isGeneratingCode}
          isDark={isDark}
          onToggleTheme={() => setIsDark((d) => !d)}
          onOpenProjectSettings={() => setSettingsModalOpen(true)}
          lastVoiceSummary={lastVoiceSummary}
        />
      )}

      {activeSection === 'github' ? (
        <GitHubWorkspace
          files={files}
          connectedRepo={connectedRepo}
          onImportFiles={handleImportFromGitHub}
          onMarkAllSynced={handleMarkAllSynced}
        />
      ) : (
        <main className="flex-1 flex flex-col lg:flex-row min-h-0 overflow-hidden">
          {/* Left File Explorer */}
          <div className={`${activeSection === 'ide' ? 'block' : 'hidden xl:block'} lg:flex min-h-0`}>
            <FileExplorer
              files={files}
              activeFilePath={activeFilePath}
              onSelectFile={handleSelectFile}
              onCreateFile={handleCreateFile}
              onDeleteFile={handleDeleteFile}
              onOpenTemplateModal={() => setTemplateModalOpen(true)}
              onSelectResourceKind={handleSelectResourceKind}
              connectedRepo={connectedRepo}
              onOpenGitHub={() => setActiveSection('github')}
            />
          </div>

          {/* Center Editor + Build Logs */}
          <div
            className={`flex-1 flex flex-col min-w-0 min-h-0 ${
              activeSection === 'emulator' ? 'hidden xl:flex' : 'flex'
            }`}
          >
            <div
              className={`${
                activeSection === 'build' ? 'hidden' : 'flex-1 min-h-[260px]'
              } flex flex-col min-h-0`}
            >
              {(() => {
                const activeFile = files.find((f) => f.path === activeFilePath) || files[0];
                const activeResKind = activeFile
                  ? getResourceKindFromPath(activeFile.path)
                  : null;

                if (activeFile && activeResKind && editorViewMode === 'table') {
                  return (
                    <ResourcesTableEditor
                      activeFile={activeFile}
                      resourceKind={activeResKind}
                      onSelectResourceKind={handleSelectResourceKind}
                      onUpdateXmlContent={handleChangeContent}
                      onSwitchToRawXml={() => setEditorViewMode('code')}
                    />
                  );
                }

                return (
                  <CodeEditorPane
                    files={files}
                    openTabs={openTabs}
                    activeFilePath={activeFilePath}
                    onSelectTab={handleSelectFile}
                    onCloseTab={handleCloseTab}
                    onChangeContent={handleChangeContent}
                    diagnostics={buildJob.diagnostics}
                    jumpToLineRequest={jumpToLineRequest}
                    canUndoVoice={voiceHistory.length > 0}
                    onUndoVoice={handleUndoVoice}
                    onSwitchToTable={
                      activeResKind ? () => setEditorViewMode('table') : undefined
                    }
                    onNavigateToMatch={(filePath, line) => {
                      setEditorViewMode('code');
                      handleSelectFile(filePath);
                      setJumpToLineRequest({ file: filePath, line, nonce: Date.now() });
                    }}
                  />
                );
              })()}
            </div>

            <div
              className={`${
                activeSection === 'build'
                  ? 'flex-1 min-h-0'
                  : activeSection === 'ide'
                  ? 'hidden lg:flex lg:h-64 xl:h-72 shrink-0'
                  : 'hidden'
              } flex-col min-h-0`}
            >
              <BuildLogsPane
                buildJob={buildJob}
                logcatEntries={logcatEntries}
                onClearLogcat={() => setLogcatEntries([])}
                onJumpToDiagnostic={handleJumpToDiagnostic}
                onFixDiagnosticsWithAi={() =>
                  void applyVoiceOrAiCommand(
                    'Исправь ошибки компиляции в этом файле, сохранив логику приложения.',
                    'fix'
                  )
                }
                isFixingAi={isGeneratingCode}
              />
            </div>
          </div>

          {/* Right Cloud Emulator */}
          <div
            className={`${
              activeSection === 'emulator'
                ? 'flex-1 xl:flex-none flex'
                : 'hidden xl:flex'
            } min-h-0`}
          >
            <CloudEmulatorPane
              screenSpec={screenSpec}
              buildStatus={buildJob.status}
              onEmitLogcat={emitLogcat}
            />
          </div>
        </main>
      )}

      {settingsModalOpen && (
        <ProjectConfigModal
          config={config}
          onSave={setConfig}
          onClose={() => setSettingsModalOpen(false)}
        />
      )}

      {templateModalOpen && (
        <ScreenTemplateModal
          applicationId={config.applicationId}
          onGenerateFiles={handleGenerateFromTemplate}
          onClose={() => setTemplateModalOpen(false)}
        />
      )}
    </div>
  );
}
