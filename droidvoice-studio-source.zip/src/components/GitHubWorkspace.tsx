import React, { useEffect, useState } from 'react';
import {
  DownloadCloud,
  ExternalLink,
  FolderGit2,
  GitBranch,
  GitCommitHorizontal,
  Loader2,
  LogOut,
  Plus,
  RefreshCw,
  UploadCloud,
} from 'lucide-react';
import {
  ConnectedRepo,
  GitHubCommitItem,
  GitHubRepoSummary,
  GitHubUser,
  ProjectFile,
} from '../types';

interface GitHubWorkspaceProps {
  files: ProjectFile[];
  connectedRepo: ConnectedRepo | null;
  onImportFiles: (files: ProjectFile[], repo: ConnectedRepo) => void;
  onMarkAllSynced: (repo: ConnectedRepo) => void;
}

export const GitHubWorkspace: React.FC<GitHubWorkspaceProps> = ({
  files,
  connectedRepo,
  onImportFiles,
  onMarkAllSynced,
}) => {
  const [oauthConfigured, setOauthConfigured] = useState(false);
  const [authenticated, setAuthenticated] = useState(false);
  const [user, setUser] = useState<GitHubUser | null>(null);
  const [callbackUrl, setCallbackUrl] = useState('');
  const [userRepos, setUserRepos] = useState<GitHubRepoSummary[]>([]);
  const [loadingStatus, setLoadingStatus] = useState(true);

  const [repoInput, setRepoInput] = useState(
    connectedRepo ? `${connectedRepo.owner}/${connectedRepo.repo}` : 'android/snippets'
  );
  const [selectedBranch, setSelectedBranch] = useState(connectedRepo?.branch || 'main');
  const [branches, setBranches] = useState<string[]>(connectedRepo?.branches || ['main']);
  const [commits, setCommits] = useState<GitHubCommitItem[]>(connectedRepo?.commits || []);
  const [repoDescription, setRepoDescription] = useState<string | null>(null);

  const [commitMessage, setCommitMessage] = useState('Обновление Android-проекта из DroidVoice Studio');
  const [newRepoName, setNewRepoName] = useState('');
  const [newRepoPrivate, setNewRepoPrivate] = useState(false);
  const [showCreateForm, setShowCreateForm] = useState(false);

  const [busyAction, setBusyAction] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const fetchAuthStatus = async () => {
    setLoadingStatus(true);
    try {
      const resp = await fetch('/api/auth/github/status');
      const data = (await resp.json()) as {
        oauthConfigured: boolean;
        authenticated: boolean;
        user: GitHubUser | null;
        callbackUrl: string;
      };
      setOauthConfigured(data.oauthConfigured);
      setAuthenticated(data.authenticated);
      setUser(data.user);
      setCallbackUrl(data.callbackUrl);

      if (data.authenticated) {
        const reposResp = await fetch('/api/github/repos');
        if (reposResp.ok) {
          const reposJson = (await reposResp.json()) as { repos: GitHubRepoSummary[] };
          setUserRepos(reposJson.repos || []);
        }
      } else {
        setUserRepos([]);
      }
    } catch {
      setErrorMessage('Не удалось проверить статус GitHub');
    } finally {
      setLoadingStatus(false);
    }
  };

  useEffect(() => {
    void fetchAuthStatus();
  }, []);

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      const origin = event.origin;
      if (!origin.endsWith('.run.app') && !origin.includes('localhost')) {
        return;
      }
      if (event.data?.type === 'OAUTH_AUTH_SUCCESS') {
        setStatusMessage('Аккаунт GitHub подключен');
        void fetchAuthStatus();
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  const handleConnectOAuth = async () => {
    setErrorMessage(null);
    setStatusMessage(null);
    try {
      const resp = await fetch('/api/auth/github/url');
      const data = (await resp.json()) as { url?: string; error?: string };
      if (!resp.ok || !data.url) {
        setErrorMessage(data.error || 'OAuth не настроен');
        return;
      }
      const popup = window.open(data.url, 'github_oauth_popup', 'width=620,height=720');
      if (!popup) {
        setErrorMessage('Разрешите всплывающие окна в браузере для входа в GitHub.');
      }
    } catch {
      setErrorMessage('Ошибка запуска GitHub OAuth');
    }
  };

  const handleLogout = async () => {
    await fetch('/api/auth/github/logout', { method: 'POST' });
    setAuthenticated(false);
    setUser(null);
    setUserRepos([]);
    setStatusMessage('Сессия GitHub завершена');
  };

  const parseOwnerRepo = (input: string) => {
    const cleaned = input
      .trim()
      .replace(/^https?:\/\/github\.com\//i, '')
      .replace(/\.git$/i, '')
      .replace(/^\/+|\/+$/g, '');
    const parts = cleaned.split('/');
    if (parts.length < 2) return null;
    return { owner: parts[0], repo: parts[1] };
  };

  const handleInspectRepo = async (target?: string, branchOverride?: string) => {
    const parsed = parseOwnerRepo(target ?? repoInput);
    if (!parsed) {
      setErrorMessage('Укажите репозиторий в формате owner/repo');
      return;
    }

    setBusyAction('inspect');
    setErrorMessage(null);
    setStatusMessage(null);
    try {
      const params = new URLSearchParams({
        owner: parsed.owner,
        repo: parsed.repo,
      });
      if (branchOverride) params.set('branch', branchOverride);

      const resp = await fetch(`/api/github/repo-info?${params.toString()}`);
      const data = (await resp.json()) as {
        repo?: { description: string | null };
        branch?: string;
        branches?: string[];
        commits?: GitHubCommitItem[];
        error?: string;
      };
      if (!resp.ok) {
        throw new Error(data.error || 'Репозиторий недоступен');
      }

      setRepoInput(`${parsed.owner}/${parsed.repo}`);
      setSelectedBranch(data.branch || 'main');
      setBranches(data.branches || ['main']);
      setCommits(data.commits || []);
      setRepoDescription(data.repo?.description || null);
      setStatusMessage(`Загружена история ${parsed.owner}/${parsed.repo} (${data.branch})`);
    } catch (err: unknown) {
      setErrorMessage(err instanceof Error ? err.message : 'Ошибка запроса GitHub');
    } finally {
      setBusyAction(null);
    }
  };

  const handlePullProject = async () => {
    const parsed = parseOwnerRepo(repoInput);
    if (!parsed) {
      setErrorMessage('Укажите репозиторий в формате owner/repo');
      return;
    }

    setBusyAction('pull');
    setErrorMessage(null);
    setStatusMessage(null);
    try {
      const resp = await fetch('/api/github/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          owner: parsed.owner,
          repo: parsed.repo,
          branch: selectedBranch,
        }),
      });
      const data = (await resp.json()) as { files?: ProjectFile[]; error?: string };
      if (!resp.ok || !data.files) {
        throw new Error(data.error || 'Не удалось импортировать файлы');
      }

      onImportFiles(data.files, {
        owner: parsed.owner,
        repo: parsed.repo,
        branch: selectedBranch,
        branches,
        lastSyncedAt: new Date().toLocaleTimeString('ru-RU'),
        commits,
      });
      setStatusMessage(`Импортировано файлов: ${data.files.length} из ${parsed.owner}/${parsed.repo}`);
    } catch (err: unknown) {
      setErrorMessage(err instanceof Error ? err.message : 'Ошибка клонирования');
    } finally {
      setBusyAction(null);
    }
  };

  const handleCreateRepo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRepoName.trim()) return;
    setBusyAction('create');
    setErrorMessage(null);
    try {
      const resp = await fetch('/api/github/create-repo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newRepoName.trim(),
          isPrivate: newRepoPrivate,
        }),
      });
      const data = (await resp.json()) as { repo?: GitHubRepoSummary; error?: string };
      if (!resp.ok || !data.repo) {
        throw new Error(data.error || 'Ошибка создания репозитория');
      }
      setUserRepos((prev) => [data.repo!, ...prev]);
      setRepoInput(data.repo.full_name);
      setSelectedBranch(data.repo.default_branch || 'main');
      setShowCreateForm(false);
      setNewRepoName('');
      setStatusMessage(`Создан репозиторий ${data.repo.full_name}`);
    } catch (err: unknown) {
      setErrorMessage(err instanceof Error ? err.message : 'Не удалось создать репозиторий');
    } finally {
      setBusyAction(null);
    }
  };

  const handlePushCommit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = parseOwnerRepo(repoInput);
    if (!parsed) {
      setErrorMessage('Выберите целевой репозиторий owner/repo');
      return;
    }

    setBusyAction('push');
    setErrorMessage(null);
    setStatusMessage(null);
    try {
      const resp = await fetch('/api/github/push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          owner: parsed.owner,
          repo: parsed.repo,
          branch: selectedBranch,
          message: commitMessage,
          files,
        }),
      });
      const data = (await resp.json()) as {
        commitSha?: string;
        message?: string;
        branch?: string;
        error?: string;
      };
      if (!resp.ok) {
        throw new Error(data.error || 'Ошибка отправки в GitHub');
      }

      onMarkAllSynced({
        owner: parsed.owner,
        repo: parsed.repo,
        branch: selectedBranch,
        branches,
        lastSyncedAt: new Date().toLocaleTimeString('ru-RU'),
        commits,
      });
      setStatusMessage(`Коммит ${data.commitSha} отправлен в ${parsed.owner}/${parsed.repo} (${data.branch})`);
      void handleInspectRepo(`${parsed.owner}/${parsed.repo}`, selectedBranch);
    } catch (err: unknown) {
      setErrorMessage(err instanceof Error ? err.message : 'Ошибка push в GitHub');
    } finally {
      setBusyAction(null);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 lg:p-6 bg-slate-50 dark:bg-[#0B0F17]">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Account & OAuth Header */}
        <div className="p-5 rounded-xl bg-white dark:bg-[#111724] border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <h1 className="font-display text-lg font-bold text-slate-900 dark:text-slate-50">
              Синхронизация и управление GitHub
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
              Клонируйте публичные Android-репозитории или подключите аккаунт GitHub для создания репозиториев и отправки коммитов.
            </p>
          </div>

          <div className="shrink-0">
            {loadingStatus ? (
              <div className="inline-flex items-center gap-2 text-xs text-slate-500">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Проверка…</span>
              </div>
            ) : authenticated && user ? (
              <div className="flex items-center gap-3">
                <img
                  src={user.avatar_url}
                  alt={user.login}
                  referrerPolicy="no-referrer"
                  className="w-8 h-8 rounded-full border border-slate-300 dark:border-slate-700 object-cover"
                />
                <div className="text-xs">
                  <div className="font-semibold text-slate-900 dark:text-slate-100">
                    {user.name || user.login}
                  </div>
                  <div className="font-mono text-slate-500">@{user.login}</div>
                </div>
                <button
                  type="button"
                  onClick={handleLogout}
                  className="p-2 rounded-lg text-slate-500 hover:text-red-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                  title="Выйти из GitHub"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={handleConnectOAuth}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <FolderGit2 className="w-4 h-4" />
                <span>Войти через GitHub</span>
              </button>
            )}
          </div>
        </div>

        {!oauthConfigured && !authenticated && (
          <div className="p-4 rounded-xl bg-white dark:bg-[#111724] border border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-400 space-y-1.5">
            <div className="font-semibold text-slate-900 dark:text-slate-200">
              Режим публичных репозиториев активен
            </div>
            <p>
              Импорт и просмотр истории любых открытых репозиториев работают сразу. Для записи коммитов настройте GitHub OAuth App с Callback URL{' '}
              <code className="font-mono text-emerald-600 dark:text-emerald-400">{callbackUrl}</code>{' '}
              и добавьте <code className="font-mono">GITHUB_CLIENT_ID</code> /{' '}
              <code className="font-mono">GITHUB_CLIENT_SECRET</code> в настройки секретов.
            </p>
          </div>
        )}

        {statusMessage && (
          <div className="px-4 py-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-700 dark:text-emerald-300">
            {statusMessage}
          </div>
        )}
        {errorMessage && (
          <div className="px-4 py-3 rounded-xl bg-red-500/10 border border-red-500/30 text-xs text-red-700 dark:text-red-300">
            {errorMessage}
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left: Repo selector & user repos */}
          <div className="lg:col-span-5 space-y-4">
            <div className="p-4 rounded-xl bg-white dark:bg-[#111724] border border-slate-200 dark:border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                  Выбор репозитория
                </h2>
                {authenticated && (
                  <button
                    type="button"
                    onClick={() => setShowCreateForm((v) => !v)}
                    className="inline-flex items-center gap-1 text-xs font-medium text-emerald-600 dark:text-emerald-400 hover:underline cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Новый репозиторий</span>
                  </button>
                )}
              </div>

              {showCreateForm && (
                <form onSubmit={handleCreateRepo} className="p-3 rounded-lg bg-slate-50 dark:bg-[#0B0F17] border border-slate-200 dark:border-slate-800 space-y-2.5">
                  <input
                    type="text"
                    value={newRepoName}
                    onChange={(e) => setNewRepoName(e.target.value)}
                    placeholder="Название репозитория (например droidvoice-notes)"
                    className="w-full px-3 py-1.5 rounded text-xs bg-white dark:bg-[#111724] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
                  />
                  <label className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300">
                    <input
                      type="checkbox"
                      checked={newRepoPrivate}
                      onChange={(e) => setNewRepoPrivate(e.target.checked)}
                    />
                    <span>Приватный репозиторий</span>
                  </label>
                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setShowCreateForm(false)}
                      className="px-2.5 py-1 text-xs text-slate-500 cursor-pointer"
                    >
                      Отмена
                    </button>
                    <button
                      type="submit"
                      disabled={busyAction === 'create'}
                      className="px-3 py-1 rounded text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer"
                    >
                      Создать
                    </button>
                  </div>
                </form>
              )}

              <div className="flex gap-2">
                <input
                  type="text"
                  value={repoInput}
                  onChange={(e) => setRepoInput(e.target.value)}
                  placeholder="owner/repo или URL GitHub"
                  className="flex-1 px-3 py-2 rounded-lg text-xs font-mono bg-slate-50 dark:bg-[#0B0F17] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
                />
                <button
                  type="button"
                  onClick={() => void handleInspectRepo()}
                  disabled={busyAction === 'inspect'}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  {busyAction === 'inspect' ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <RefreshCw className="w-3.5 h-3.5" />
                  )}
                  <span>Загрузить</span>
                </button>
              </div>

              <div className="flex items-center justify-between gap-2 pt-1">
                <div className="flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-300">
                  <GitBranch className="w-3.5 h-3.5 text-slate-400" />
                  <select
                    value={selectedBranch}
                    onChange={(e) => {
                      setSelectedBranch(e.target.value);
                      void handleInspectRepo(repoInput, e.target.value);
                    }}
                    aria-label="Ветка репозитория"
                    className="px-2 py-1 rounded bg-slate-50 dark:bg-[#0B0F17] border border-slate-300 dark:border-slate-700 text-xs font-mono"
                  >
                    {branches.map((b) => (
                      <option key={b} value={b}>
                        {b}
                      </option>
                    ))}
                  </select>
                </div>

                <button
                  type="button"
                  onClick={handlePullProject}
                  disabled={busyAction === 'pull'}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-50"
                >
                  {busyAction === 'pull' ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <DownloadCloud className="w-3.5 h-3.5" />
                  )}
                  <span>Импортировать в IDE</span>
                </button>
              </div>

              {repoDescription && (
                <p className="text-xs text-slate-500 dark:text-slate-400 pt-1">
                  {repoDescription}
                </p>
              )}
            </div>

            {userRepos.length > 0 && (
              <div className="p-4 rounded-xl bg-white dark:bg-[#111724] border border-slate-200 dark:border-slate-800 space-y-2">
                <h3 className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                  Ваши репозитории ({userRepos.length})
                </h3>
                <div className="max-h-64 overflow-y-auto divide-y divide-slate-200 dark:divide-slate-800/80">
                  {userRepos.map((r) => (
                    <button
                      key={r.id}
                      type="button"
                      onClick={() => void handleInspectRepo(r.full_name, r.default_branch)}
                      className="w-full py-2 text-left flex items-center justify-between gap-2 hover:text-emerald-500 transition-colors cursor-pointer"
                    >
                      <div className="min-w-0">
                        <div className="text-xs font-mono font-medium truncate">{r.full_name}</div>
                        <div className="text-[11px] text-slate-400">
                          {r.language || 'Project'} · {r.private ? 'Приватный' : 'Публичный'}
                        </div>
                      </div>
                      <span className="text-[11px] font-mono text-slate-400 shrink-0">
                        {r.default_branch}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right: Push & Commit history */}
          <div className="lg:col-span-7 space-y-4">
            <form
              onSubmit={handlePushCommit}
              className="p-4 rounded-xl bg-white dark:bg-[#111724] border border-slate-200 dark:border-slate-800 space-y-3"
            >
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                  Отправить изменения в GitHub (Commit & Push)
                </h2>
                <span className="text-xs font-mono text-slate-500 tabular-nums">
                  Файлов в коммите: {files.length}
                </span>
              </div>

              <input
                type="text"
                value={commitMessage}
                onChange={(e) => setCommitMessage(e.target.value)}
                placeholder="Сообщение коммита..."
                className="w-full px-3 py-2 rounded-lg text-xs bg-slate-50 dark:bg-[#0B0F17] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
              />

              <div className="flex items-center justify-between gap-3">
                <span className="text-xs text-slate-500 dark:text-slate-400">
                  Измененные файлы: {files.filter((f) => f.modified).length}
                </span>
                <button
                  type="submit"
                  disabled={!authenticated || busyAction === 'push'}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-white disabled:opacity-40 transition-colors cursor-pointer disabled:cursor-not-allowed whitespace-nowrap shrink-0"
                >
                  {busyAction === 'push' ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <UploadCloud className="w-3.5 h-3.5" />
                  )}
                  <span>Отправить коммит</span>
                </button>
              </div>
            </form>

            <div className="p-4 rounded-xl bg-white dark:bg-[#111724] border border-slate-200 dark:border-slate-800 space-y-3">
              <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                Последние коммиты ветки {selectedBranch}
              </h3>

              {commits.length === 0 ? (
                <div className="py-6 text-center text-xs text-slate-500 dark:text-slate-400">
                  Нажмите «Загрузить», чтобы просмотреть историю коммитов репозитория.
                </div>
              ) : (
                <div className="divide-y divide-slate-200 dark:divide-slate-800/80">
                  {commits.map((c) => (
                    <div key={c.sha} className="py-2.5 flex items-start justify-between gap-3 text-xs">
                      <div className="flex items-start gap-2.5 min-w-0">
                        <GitCommitHorizontal className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
                        <div className="min-w-0">
                          <div className="font-medium text-slate-900 dark:text-slate-100 truncate">
                            {c.message}
                          </div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                            {c.author} · {c.date ? new Date(c.date).toLocaleDateString('ru-RU') : ''}
                          </div>
                        </div>
                      </div>
                      <a
                        href={c.html_url}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 font-mono text-[11px] text-emerald-600 dark:text-emerald-400 hover:underline shrink-0"
                      >
                        <span>{c.sha}</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
