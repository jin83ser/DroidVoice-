import React, { useEffect, useState } from 'react';
import {
  BatteryCharging,
  ChevronLeft,
  Circle,
  RotateCw,
  Smartphone,
  Square,
  Wifi,
  WifiOff,
  Power,
  Camera,
} from 'lucide-react';
import { EmulatorScreenSpec, EmulatorWidgetSpec, LogcatEntry } from '../types';

interface CloudEmulatorPaneProps {
  screenSpec: EmulatorScreenSpec;
  buildStatus: 'idle' | 'queued' | 'compiling' | 'packaging' | 'success' | 'failed';
  onEmitLogcat: (level: LogcatEntry['level'], tag: string, message: string) => void;
}

type DeviceProfile = 'pixel8' | 'galaxy24' | 'tablet';

const DEVICE_PROFILES: Record<DeviceProfile, { name: string; api: string; widthClass: string }> = {
  pixel8: { name: 'Pixel 8 Pro', api: 'API 35', widthClass: 'max-w-[300px]' },
  galaxy24: { name: 'Galaxy S24', api: 'API 34', widthClass: 'max-w-[290px]' },
  tablet: { name: 'Pixel Tablet', api: 'API 34', widthClass: 'max-w-[360px]' },
};

export const CloudEmulatorPane: React.FC<CloudEmulatorPaneProps> = ({
  screenSpec,
  buildStatus,
  onEmitLogcat,
}) => {
  const [profile, setProfile] = useState<DeviceProfile>('pixel8');
  const [landscape, setLandscape] = useState(false);
  const [online, setOnline] = useState(true);
  const [rebooting, setRebooting] = useState(false);
  const [launcherMode, setLauncherMode] = useState(false);
  const [toastText, setToastText] = useState<string | null>(null);
  const [appState, setAppState] = useState<Record<string, string | number | boolean>>(
    screenSpec.initialState
  );

  // Sync emulator state when a new compiled screen spec arrives
  useEffect(() => {
    setAppState(screenSpec.initialState);
    setLauncherMode(false);
  }, [screenSpec]);

  const showToast = (msg: string) => {
    setToastText(msg);
    setTimeout(() => {
      setToastText((curr) => (curr === msg ? null : curr));
    }, 2200);
  };

  const handleWidgetAction = (widget: EmulatorWidgetSpec) => {
    if (!online && widget.action === 'submit') {
      showToast('Нет сети (Offline режим эмулятора)');
      onEmitLogcat('W', 'NetworkMonitor', 'Запрос отклонен: эмулятор в Offline режиме');
      return;
    }

    if (widget.action === 'increment') {
      const next = Number(appState.counter || 0) + 1;
      setAppState((prev) => ({ ...prev, counter: next }));
      onEmitLogcat('D', 'ComposeUI', `Нажатие «${widget.label}» -> counter=${next}`);
      showToast(widget.toastMessage || `Обновлено: ${next}`);
    } else if (widget.action === 'decrement') {
      const next = Math.max(0, Number(appState.counter || 0) - 1);
      setAppState((prev) => ({ ...prev, counter: next }));
      onEmitLogcat('D', 'ComposeUI', `Уменьшено -> counter=${next}`);
    } else if (widget.action === 'reset') {
      setAppState((prev) => ({ ...prev, counter: 0, input_note: '' }));
      onEmitLogcat('W', 'ComposeUI', 'Состояние экрана сброшено пользователем');
      showToast(widget.toastMessage || 'Состояние сброшено');
    } else if (widget.action === 'toggle') {
      const key = widget.stateKey || 'switch_sync';
      const nextVal = !Boolean(appState[key]);
      setAppState((prev) => ({ ...prev, [key]: nextVal }));
      onEmitLogcat('I', 'SyncSwitch', `${widget.label}: ${nextVal}`);
    } else {
      onEmitLogcat('I', 'ComposeUI', `Клик по «${widget.label}»`);
      showToast(widget.toastMessage || widget.label);
    }
  };

  const handleColdReboot = () => {
    setRebooting(true);
    onEmitLogcat('I', 'CloudEmulator', `Холодная перезагрузка ${DEVICE_PROFILES[profile].name}...`);
    setTimeout(() => {
      setRebooting(false);
      setLauncherMode(false);
      setAppState(screenSpec.initialState);
      onEmitLogcat('I', 'ActivityManager', `Запущен пакет ${screenSpec.packageName}/.MainActivity`);
    }, 850);
  };

  const handleScreenshot = () => {
    onEmitLogcat('I', 'ScreenCapture', `Снимок экрана сохранен (${DEVICE_PROFILES[profile].name})`);
    showToast('Снимок экрана сохранен в Logcat');
  };

  const dev = DEVICE_PROFILES[profile];

  return (
    <aside
      aria-label="Облачный эмулятор Android"
      className="w-full xl:w-[390px] shrink-0 border-t xl:border-t-0 xl:border-l border-slate-200 dark:border-slate-800/90 bg-slate-50 dark:bg-[#0E131D] flex flex-col min-h-0"
    >
      {/* Emulator Header & Controls */}
      <div className="px-4 py-3 border-b border-slate-200 dark:border-slate-800/90 flex items-center justify-between gap-2 shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <Smartphone className="w-4 h-4 text-emerald-500 shrink-0" />
          <h2 className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate">
            Облачный эмулятор
          </h2>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <select
            value={profile}
            onChange={(e) => setProfile(e.target.value as DeviceProfile)}
            aria-label="Профиль устройства"
            className="text-[11px] font-medium px-2 py-1 rounded bg-white dark:bg-[#161E2E] border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-200 focus:outline-none"
          >
            <option value="pixel8">Pixel 8 Pro · API 35</option>
            <option value="galaxy24">Galaxy S24 · API 34</option>
            <option value="tablet">Pixel Tablet · API 34</option>
          </select>

          <button
            type="button"
            onClick={() => setLandscape((v) => !v)}
            title="Повернуть экран"
            className="p-1.5 rounded text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100 hover:bg-slate-200/70 dark:hover:bg-slate-800 cursor-pointer"
          >
            <RotateCw className="w-3.5 h-3.5" />
          </button>

          <button
            type="button"
            onClick={() => {
              const next = !online;
              setOnline(next);
              onEmitLogcat('I', 'ConnectivityService', next ? 'Сеть 5G подключена' : 'Режим Offline включен');
            }}
            title={online ? 'Сеть 5G включена' : 'Offline режим'}
            className="p-1.5 rounded text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100 hover:bg-slate-200/70 dark:hover:bg-slate-800 cursor-pointer"
          >
            {online ? <Wifi className="w-3.5 h-3.5 text-emerald-500" /> : <WifiOff className="w-3.5 h-3.5 text-amber-500" />}
          </button>

          <button
            type="button"
            onClick={handleScreenshot}
            title="Снимок экрана"
            className="p-1.5 rounded text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100 hover:bg-slate-200/70 dark:hover:bg-slate-800 cursor-pointer"
          >
            <Camera className="w-3.5 h-3.5" />
          </button>

          <button
            type="button"
            onClick={handleColdReboot}
            title="Перезагрузить эмулятор"
            className="p-1.5 rounded text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100 hover:bg-slate-200/70 dark:hover:bg-slate-800 cursor-pointer"
          >
            <Power className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Emulator Viewport */}
      <div className="flex-1 overflow-y-auto p-4 flex flex-col items-center justify-center">
        <div
          className={`w-full transition-all duration-300 ${
            landscape ? 'max-w-[350px] aspect-[16/10]' : `${dev.widthClass} min-h-[500px]`
          } rounded-[28px] p-2.5 bg-slate-900 border border-slate-700/80 shadow-xl flex flex-col relative`}
        >
          {/* Speaker / Camera Notch */}
          <div className="flex items-center justify-center pb-1.5 shrink-0">
            <div className="w-16 h-1.5 rounded-full bg-slate-800" />
          </div>

          {/* Android Screen Surface */}
          <div
            className={`flex-1 rounded-[20px] overflow-hidden flex flex-col relative ${
              screenSpec.darkSurface ? 'bg-[#0B0F17] text-slate-100' : 'bg-white text-slate-900'
            }`}
          >
            {/* Android Status Bar */}
            <div className="h-6 px-3.5 flex items-center justify-between text-[10px] font-mono tabular-nums opacity-80 shrink-0">
              <span>23:17</span>
              <div className="flex items-center gap-1.5">
                <span>{online ? '5G' : 'No Sim'}</span>
                <BatteryCharging className="w-3 h-3" />
                <span>96%</span>
              </div>
            </div>

            {rebooting ? (
              <div className="flex-1 flex flex-col items-center justify-center gap-3 p-6 text-center">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center">
                  <Smartphone className="w-5 h-5 text-emerald-400 animate-pulse" />
                </div>
                <p className="text-xs font-medium opacity-80">Загрузка Android Runtime…</p>
              </div>
            ) : launcherMode ? (
              <div className="flex-1 flex flex-col items-center justify-center p-6 gap-4">
                <button
                  type="button"
                  onClick={() => {
                    setLauncherMode(false);
                    onEmitLogcat('I', 'ActivityManager', `Запуск ${screenSpec.packageName}`);
                  }}
                  className="flex flex-col items-center gap-2 group cursor-pointer"
                >
                  <div className="w-14 h-14 rounded-2xl bg-emerald-600 text-white flex items-center justify-center text-lg font-bold shadow-md group-hover:scale-105 transition-transform">
                    {screenSpec.appTitle.slice(0, 2).toUpperCase()}
                  </div>
                  <span className="text-xs font-medium">{screenSpec.appTitle}</span>
                </button>
                <p className="text-[11px] opacity-60 text-center">
                  Нажмите на иконку, чтобы открыть приложение
                </p>
              </div>
            ) : (
              <>
                {/* Material 3 TopAppBar */}
                <div
                  className={`px-4 py-3 border-b shrink-0 flex items-center justify-between ${
                    screenSpec.darkSurface
                      ? 'border-slate-800 bg-[#111724]'
                      : 'border-slate-200 bg-slate-50'
                  }`}
                >
                  <span className="text-sm font-semibold truncate">{screenSpec.appTitle}</span>
                  <span className="text-[10px] font-mono opacity-60 shrink-0">
                    {buildStatus === 'success' ? 'APK Live' : 'Preview'}
                  </span>
                </div>

                {/* Rendered Jetpack Compose Widgets */}
                <div className="flex-1 overflow-y-auto p-3.5 space-y-3">
                  {screenSpec.widgets.map((w) => {
                    if (w.type === 'card') {
                      const displayLabel = w.label.includes('$')
                        ? w.label.replace(/\$\w+/g, String(appState.counter ?? 0))
                        : w.label.replace(/:\s*\d+/, `: ${appState.counter ?? 0}`);
                      return (
                        <div
                          key={w.id}
                          className={`p-3.5 rounded-xl border ${
                            screenSpec.darkSurface
                              ? 'bg-[#151D2C] border-slate-800'
                              : 'bg-slate-50 border-slate-200'
                          }`}
                        >
                          <div className="text-xs font-semibold">{displayLabel}</div>
                          {w.sublabel && (
                            <div className="mt-1 text-[11px] opacity-70">{w.sublabel}</div>
                          )}
                          <div className="mt-2 text-[11px] font-mono tabular-nums text-emerald-500">
                            Счетчик состояния: {String(appState.counter ?? 0)}
                          </div>
                        </div>
                      );
                    }

                    if (w.type === 'input') {
                      const key = w.stateKey || 'input_note';
                      return (
                        <div key={w.id} className="space-y-1">
                          <label className="block text-[11px] opacity-70">{w.label}</label>
                          <input
                            type="text"
                            value={String(appState[key] || '')}
                            onChange={(e) =>
                              setAppState((prev) => ({ ...prev, [key]: e.target.value }))
                            }
                            placeholder="Введите текст..."
                            className={`w-full px-3 py-2 rounded-lg text-xs border focus:outline-none focus:border-emerald-500 ${
                              screenSpec.darkSurface
                                ? 'bg-[#0B0F17] border-slate-700 text-slate-100'
                                : 'bg-white border-slate-300 text-slate-900'
                            }`}
                          />
                        </div>
                      );
                    }

                    if (w.type === 'switch') {
                      const key = w.stateKey || 'switch_sync';
                      const checked = Boolean(appState[key]);
                      return (
                        <div key={w.id} className="flex items-center justify-between gap-2 py-1">
                          <span className="text-xs">{w.label}</span>
                          <button
                            type="button"
                            role="switch"
                            aria-checked={checked}
                            onClick={() => handleWidgetAction(w)}
                            className={`w-10 h-5 rounded-full p-0.5 transition-colors cursor-pointer ${
                              checked ? 'bg-emerald-500' : 'bg-slate-600'
                            }`}
                          >
                            <div
                              className={`w-4 h-4 rounded-full bg-white transition-transform ${
                                checked ? 'translate-x-5' : 'translate-x-0'
                              }`}
                            />
                          </button>
                        </div>
                      );
                    }

                    if (w.type === 'progress') {
                      return (
                        <div key={w.id} className="space-y-1">
                          <div className="flex justify-between text-[11px]">
                            <span>{w.label}</span>
                            <span className="font-mono tabular-nums">{w.progressValue ?? 68}%</span>
                          </div>
                          <div className="h-1.5 rounded-full bg-slate-700/40 overflow-hidden">
                            <div
                              className="h-full bg-emerald-500"
                              style={{ width: `${w.progressValue ?? 68}%` }}
                            />
                          </div>
                        </div>
                      );
                    }

                    if (w.type === 'button') {
                      const isOutline = w.variant === 'outline';
                      return (
                        <button
                          key={w.id}
                          type="button"
                          onClick={() => handleWidgetAction(w)}
                          className={`w-full py-2.5 px-3 rounded-xl text-xs font-semibold transition-opacity active:opacity-80 cursor-pointer ${
                            isOutline
                              ? 'border border-slate-500/50 hover:bg-slate-500/10'
                              : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                          }`}
                        >
                          {w.label}
                        </button>
                      );
                    }

                    return (
                      <div key={w.id} className="text-xs opacity-85">
                        {w.label}
                      </div>
                    );
                  })}
                </div>

                {/* Floating Action Button */}
                {screenSpec.fabLabel && (
                  <button
                    type="button"
                    onClick={() =>
                      handleWidgetAction({
                        id: 'fab',
                        type: 'button',
                        label: 'FAB',
                        action: screenSpec.fabAction || 'increment',
                        toastMessage: 'Добавлена новая запись',
                      })
                    }
                    className="absolute right-3.5 bottom-12 w-11 h-11 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-base shadow-lg flex items-center justify-center cursor-pointer"
                  >
                    {screenSpec.fabLabel}
                  </button>
                )}

                {/* Android Toast Overlay */}
                {toastText && (
                  <div className="absolute bottom-11 left-1/2 -translate-x-1/2 px-3 py-1.5 rounded-lg bg-slate-800/95 text-white text-[11px] whitespace-nowrap shadow-md pointer-events-none">
                    {toastText}
                  </div>
                )}
              </>
            )}

            {/* Android System Navigation Bar */}
            <div
              className={`h-8 border-t flex items-center justify-around shrink-0 ${
                screenSpec.darkSurface ? 'border-slate-800 bg-[#0B0F17]' : 'border-slate-200 bg-slate-50'
              }`}
            >
              <button
                type="button"
                aria-label="Назад"
                onClick={() => {
                  setToastText(null);
                  onEmitLogcat('D', 'InputDispatcher', 'KeyEvent BACK');
                }}
                className="p-1.5 opacity-60 hover:opacity-100 cursor-pointer"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                aria-label="Домой"
                onClick={() => {
                  setLauncherMode((v) => !v);
                  onEmitLogcat('D', 'InputDispatcher', 'KeyEvent HOME');
                }}
                className="p-1.5 opacity-60 hover:opacity-100 cursor-pointer"
              >
                <Circle className="w-3 h-3" />
              </button>
              <button
                type="button"
                aria-label="Недавние приложения"
                onClick={() => {
                  showToast(`Запущено: ${screenSpec.appTitle}`);
                  onEmitLogcat('D', 'InputDispatcher', 'KeyEvent APP_SWITCH');
                }}
                className="p-1.5 opacity-60 hover:opacity-100 cursor-pointer"
              >
                <Square className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>

        {/* Device Meta Below Chassis (Unboxed) */}
        <div className="mt-3 text-[11px] font-mono text-slate-500 dark:text-slate-400 flex items-center gap-2">
          <span>{dev.name}</span>
          <span aria-hidden="true">·</span>
          <span>{dev.api}</span>
          <span aria-hidden="true">·</span>
          <span>{online ? 'Online' : 'Offline'}</span>
        </div>
      </div>
    </aside>
  );
};
