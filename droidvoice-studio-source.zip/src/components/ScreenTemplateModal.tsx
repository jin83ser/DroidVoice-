import React, { useState } from 'react';
import {
  BarChart3,
  Check,
  FileCode2,
  FileText,
  KeyRound,
  LayoutList,
  UserRound,
  Layers,
  X,
} from 'lucide-react';
import {
  generateTemplateFiles,
  normalizeScreenNames,
  SCREEN_TEMPLATES,
  ScreenTemplateDefinition,
} from '../data/screenTemplates';
import { ProjectFile } from '../types';

interface ScreenTemplateModalProps {
  applicationId: string;
  onGenerateFiles: (files: ProjectFile[], templateTitle: string) => void;
  onClose: () => void;
}

const TEMPLATE_ICONS: Record<ScreenTemplateDefinition['id'], React.ReactNode> = {
  list: <LayoutList className="w-4 h-4 text-emerald-500" />,
  auth: <KeyRound className="w-4 h-4 text-emerald-500" />,
  analytics: <BarChart3 className="w-4 h-4 text-emerald-500" />,
  profile: <UserRound className="w-4 h-4 text-emerald-500" />,
  detail: <Layers className="w-4 h-4 text-emerald-500" />,
};

export const ScreenTemplateModal: React.FC<ScreenTemplateModalProps> = ({
  applicationId,
  onGenerateFiles,
  onClose,
}) => {
  const [selectedId, setSelectedId] = useState<ScreenTemplateDefinition['id']>('list');
  const [screenName, setScreenName] = useState(SCREEN_TEMPLATES[0].defaultScreenName);
  const [nameEditedManually, setNameEditedManually] = useState(false);

  const selectedTemplate =
    SCREEN_TEMPLATES.find((t) => t.id === selectedId) || SCREEN_TEMPLATES[0];

  const handleSelectTemplate = (tmpl: ScreenTemplateDefinition) => {
    setSelectedId(tmpl.id);
    if (!nameEditedManually) {
      setScreenName(tmpl.defaultScreenName);
    }
  };

  const { pascal, snake } = normalizeScreenNames(
    screenName,
    selectedTemplate.defaultScreenName
  );
  const pkgPath = applicationId.replace(/\./g, '/');
  const previewKtPath = `app/src/main/java/${pkgPath}/${pascal}.kt`;
  const previewXmlPath = `app/src/main/res/layout/layout_${snake}.xml`;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const generated = generateTemplateFiles(selectedId, screenName, applicationId);
    onGenerateFiles(generated, selectedTemplate.title);
    onClose();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="template-modal-title"
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4"
    >
      <div className="w-full max-w-2xl rounded-xl bg-white dark:bg-[#111724] border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0">
          <div>
            <h2
              id="template-modal-title"
              className="font-display text-sm font-bold text-slate-900 dark:text-slate-100"
            >
              Создать экран из шаблона
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Выберите предустановленный UI-компонент для генерации Kotlin и XML файлов
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Закрыть окно"
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* Template Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {SCREEN_TEMPLATES.map((tmpl) => {
              const active = tmpl.id === selectedId;
              return (
                <button
                  key={tmpl.id}
                  type="button"
                  onClick={() => handleSelectTemplate(tmpl)}
                  className={`p-3.5 rounded-xl border text-left transition-colors cursor-pointer flex flex-col justify-between gap-2 ${
                    active
                      ? 'border-emerald-500 bg-emerald-500/8 dark:bg-emerald-500/10'
                      : 'border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-[#0B0F17] hover:border-slate-300 dark:hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      {TEMPLATE_ICONS[tmpl.id]}
                      <span className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                        {tmpl.title}
                      </span>
                    </div>
                    {active && <Check className="w-4 h-4 text-emerald-500 shrink-0" />}
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                    {tmpl.description}
                  </p>

                  <div className="text-[11px] font-mono text-slate-500 dark:text-slate-500 truncate">
                    {tmpl.componentsSummary}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Screen Name Input */}
          <div className="space-y-1.5">
            <label
              htmlFor="template-screen-name"
              className="block text-xs font-medium text-slate-700 dark:text-slate-300"
            >
              Имя экрана (латиницей, для классов и ресурсов)
            </label>
            <input
              id="template-screen-name"
              type="text"
              value={screenName}
              onChange={(e) => {
                setScreenName(e.target.value);
                setNameEditedManually(true);
              }}
              placeholder={selectedTemplate.defaultScreenName}
              className="w-full px-3 py-2 rounded-lg text-xs font-mono bg-slate-50 dark:bg-[#0B0F17] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Output Files Preview */}
          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-[#0B0F17] border border-slate-200 dark:border-slate-800 space-y-2 text-xs">
            <div className="font-medium text-slate-700 dark:text-slate-300">
              Будут сгенерированы файлы:
            </div>
            <div className="flex items-center gap-2 font-mono text-[11px] text-slate-600 dark:text-slate-400">
              <FileCode2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
              <span className="truncate">{previewKtPath}</span>
            </div>
            <div className="flex items-center gap-2 font-mono text-[11px] text-slate-600 dark:text-slate-400">
              <FileText className="w-3.5 h-3.5 text-sky-500 shrink-0" />
              <span className="truncate">{previewXmlPath}</span>
            </div>
          </div>

          <div className="pt-1 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            >
              Отмена
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Создать файлы экрана
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
