import React, { useState } from 'react';
import { X } from 'lucide-react';
import { ProjectConfig } from '../types';

interface ProjectConfigModalProps {
  config: ProjectConfig;
  onSave: (next: ProjectConfig) => void;
  onClose: () => void;
}

export const ProjectConfigModal: React.FC<ProjectConfigModalProps> = ({
  config,
  onSave,
  onClose,
}) => {
  const [form, setForm] = useState<ProjectConfig>(config);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(form);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="w-full max-w-md rounded-xl bg-white dark:bg-[#111724] border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <h2 className="font-display text-sm font-bold text-slate-900 dark:text-slate-100">
            Параметры сборки Android (Gradle)
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs">
          <div className="space-y-1">
            <label className="block font-medium text-slate-700 dark:text-slate-300">
              Название приложения
            </label>
            <input
              type="text"
              value={form.projectName}
              onChange={(e) => setForm({ ...form, projectName: e.target.value })}
              className="w-full px-3 py-2 rounded-lg bg-slate-50 dark:bg-[#0B0F17] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="space-y-1">
            <label className="block font-medium text-slate-700 dark:text-slate-300">
              Application ID (Package Name)
            </label>
            <input
              type="text"
              value={form.applicationId}
              onChange={(e) => setForm({ ...form, applicationId: e.target.value })}
              className="w-full px-3 py-2 rounded-lg font-mono bg-slate-50 dark:bg-[#0B0F17] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="block font-medium text-slate-700 dark:text-slate-300">
                Version Name
              </label>
              <input
                type="text"
                value={form.versionName}
                onChange={(e) => setForm({ ...form, versionName: e.target.value })}
                className="w-full px-3 py-2 rounded-lg font-mono bg-slate-50 dark:bg-[#0B0F17] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100"
              />
            </div>
            <div className="space-y-1">
              <label className="block font-medium text-slate-700 dark:text-slate-300">
                Version Code
              </label>
              <input
                type="number"
                min={1}
                value={form.versionCode}
                onChange={(e) => setForm({ ...form, versionCode: Number(e.target.value) || 1 })}
                className="w-full px-3 py-2 rounded-lg font-mono tabular-nums bg-slate-50 dark:bg-[#0B0F17] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="block font-medium text-slate-700 dark:text-slate-300">
                minSdk
              </label>
              <input
                type="number"
                min={21}
                max={35}
                value={form.minSdk}
                onChange={(e) => setForm({ ...form, minSdk: Number(e.target.value) || 26 })}
                className="w-full px-3 py-2 rounded-lg font-mono tabular-nums bg-slate-50 dark:bg-[#0B0F17] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100"
              />
            </div>
            <div className="space-y-1">
              <label className="block font-medium text-slate-700 dark:text-slate-300">
                targetSdk
              </label>
              <input
                type="number"
                min={26}
                max={36}
                value={form.targetSdk}
                onChange={(e) => setForm({ ...form, targetSdk: Number(e.target.value) || 35 })}
                className="w-full px-3 py-2 rounded-lg font-mono tabular-nums bg-slate-50 dark:bg-[#0B0F17] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            >
              Отмена
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer"
            >
              Сохранить
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
