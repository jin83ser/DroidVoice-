import React from 'react';
import { Hammer, Loader2 } from 'lucide-react';

export type WorkspaceSection = 'ide' | 'build' | 'emulator' | 'github';

interface TopBarProps {
  activeSection: WorkspaceSection;
  onSelectSection: (section: WorkspaceSection) => void;
  onTriggerBuild: () => void;
  isBuilding: boolean;
}

const NAV_ITEMS: Array<{ id: WorkspaceSection; label: string }> = [
  { id: 'ide', label: 'Редактор' },
  { id: 'build', label: 'Сборка и логи' },
  { id: 'emulator', label: 'Эмулятор' },
  { id: 'github', label: 'GitHub' },
];

export const TopBar: React.FC<TopBarProps> = ({
  activeSection,
  onSelectSection,
  onTriggerBuild,
  isBuilding,
}) => {
  return (
    <header className="h-14 border-b border-slate-200 dark:border-slate-800/90 bg-white dark:bg-[#0E131D] px-4 lg:px-6 flex items-center justify-between gap-8 shrink-0">
      {/* Zone 1: Single-line Brand wordmark */}
      <button
        type="button"
        onClick={() => onSelectSection('ide')}
        className="font-display text-base font-bold tracking-tight text-slate-900 dark:text-slate-50 whitespace-nowrap shrink-0 focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 rounded"
      >
        DroidVoice Studio
      </button>

      {/* Zone 2: Concise single-line navigation */}
      <nav aria-label="Разделы рабочей области" className="flex items-center gap-4 lg:gap-6 overflow-x-auto no-scrollbar">
        {NAV_ITEMS.map((item) => {
          const isActive = activeSection === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectSection(item.id)}
              className={`py-1.5 text-sm font-medium whitespace-nowrap shrink-0 transition-colors border-b-2 focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 ${
                isActive
                  ? 'border-emerald-500 text-slate-900 dark:text-slate-50'
                  : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              {item.label}
            </button>
          );
        })}
      </nav>

      {/* Zone 3: Single primary action */}
      <div className="shrink-0">
        <button
          type="button"
          onClick={onTriggerBuild}
          disabled={isBuilding}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 disabled:bg-emerald-700/60 text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer disabled:cursor-not-allowed focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
        >
          {isBuilding ? (
            <>
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
              <span>Сборка APK...</span>
            </>
          ) : (
            <>
              <Hammer className="w-3.5 h-3.5" />
              <span>Собрать APK</span>
            </>
          )}
        </button>
      </div>
    </header>
  );
};
