import React, { useMemo, useState } from 'react';
import {
  FileCode2,
  FileText,
  FolderOpen,
  LayoutTemplate,
  Plus,
  Trash2,
  GitBranch,
  RefreshCw,
  Table2,
  Palette,
  Ruler,
  Type as TypeIcon,
} from 'lucide-react';
import { ConnectedRepo, ProjectFile } from '../types';
import {
  DEFAULT_RESOURCE_XML,
  getResourceKindFromPath,
  parseAndroidResourcesXml,
  RESOURCE_FILES_META,
  ResourceKind,
  toHexColorPickerValue,
} from '../utils/androidResources';

interface FileExplorerProps {
  files: ProjectFile[];
  activeFilePath: string;
  onSelectFile: (path: string) => void;
  onCreateFile: (path: string) => void;
  onDeleteFile: (path: string) => void;
  onOpenTemplateModal: () => void;
  onSelectResourceKind: (kind: ResourceKind) => void;
  connectedRepo: ConnectedRepo | null;
  onOpenGitHub: () => void;
}

type ExplorerTab = 'files' | 'resources';

export const FileExplorer: React.FC<FileExplorerProps> = ({
  files,
  activeFilePath,
  onSelectFile,
  onCreateFile,
  onDeleteFile,
  onOpenTemplateModal,
  onSelectResourceKind,
  connectedRepo,
  onOpenGitHub,
}) => {
  const [activeTab, setActiveTab] = useState<ExplorerTab>('files');
  const [selectedResKind, setSelectedResKind] = useState<ResourceKind>('strings');
  const [creating, setCreating] = useState(false);
  const [newPath, setNewPath] = useState('app/src/main/java/com/droidvoice/notes/');

  const activeResKindFromFile = getResourceKindFromPath(activeFilePath);
  const effectiveResKind = activeResKindFromFile || selectedResKind;

  const resourcePreviewEntries = useMemo(() => {
    const meta = RESOURCE_FILES_META.find((m) => m.kind === effectiveResKind)!;
    const found = files.find((f) => getResourceKindFromPath(f.path) === effectiveResKind);
    const xml = found?.content ?? DEFAULT_RESOURCE_XML[meta.kind];
    return parseAndroidResourcesXml(xml, effectiveResKind);
  }, [files, effectiveResKind]);

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = newPath.trim().replace(/^\/+/, '');
    if (!cleaned || cleaned.endsWith('/')) return;
    onCreateFile(cleaned);
    setCreating(false);
    setNewPath('app/src/main/java/com/droidvoice/notes/');
  };

  const handlePickResource = (kind: ResourceKind) => {
    setSelectedResKind(kind);
    onSelectResourceKind(kind);
  };

  return (
    <aside
      aria-label="Файлы проекта"
      className="w-full lg:w-64 shrink-0 border-b lg:border-b-0 lg:border-r border-slate-200 dark:border-slate-800/90 bg-white dark:bg-[#0E131D] flex flex-col min-h-0"
    >
      {/* Header + Segmented Tabs: Файлы / Ресурсы */}
      <div className="px-3 pt-3 pb-2 border-b border-slate-200 dark:border-slate-800/90 space-y-2.5">
        <div className="flex items-center justify-between gap-2 px-1">
          <div className="flex items-center gap-2 min-w-0">
            <FolderOpen className="w-4 h-4 text-emerald-500 shrink-0" />
            <h2 className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate">
              Структура проекта
            </h2>
          </div>
          {activeTab === 'files' && (
            <button
              type="button"
              onClick={() => setCreating((v) => !v)}
              title="Создать файл"
              className="p-1.5 rounded-md text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        <div className="grid grid-cols-2 gap-1 p-0.5 bg-slate-100 dark:bg-[#0B0F17] border border-slate-200 dark:border-slate-800 rounded-lg">
          <button
            type="button"
            onClick={() => setActiveTab('files')}
            className={`py-1.5 px-2 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'files'
                ? 'bg-white dark:bg-[#1A2233] text-slate-900 dark:text-slate-100 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            Файлы
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveTab('resources');
              onSelectResourceKind(effectiveResKind);
            }}
            className={`py-1.5 px-2 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              activeTab === 'resources'
                ? 'bg-white dark:bg-[#1A2233] text-slate-900 dark:text-slate-100 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            Ресурсы
          </button>
        </div>
      </div>

      {activeTab === 'files' ? (
        <>
          <div className="px-3 py-2 border-b border-slate-200 dark:border-slate-800/90 bg-slate-50/60 dark:bg-[#111724]">
            <button
              type="button"
              onClick={onOpenTemplateModal}
              className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium bg-white dark:bg-[#182132] border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-100 hover:border-emerald-500/70 hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <LayoutTemplate className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
              <span>Создать экран из шаблона</span>
            </button>
          </div>

          {creating && (
            <form
              onSubmit={handleCreateSubmit}
              className="p-3 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#131A26] space-y-2"
            >
              <input
                type="text"
                value={newPath}
                onChange={(e) => setNewPath(e.target.value)}
                placeholder="Путь (например Screen.kt)"
                className="w-full px-2.5 py-1.5 rounded text-xs font-mono bg-white dark:bg-[#0B0F17] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
                autoFocus
              />
              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setCreating(false)}
                  className="px-2.5 py-1 text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 cursor-pointer"
                >
                  Отмена
                </button>
                <button
                  type="submit"
                  className="px-2.5 py-1 rounded text-xs font-medium bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer"
                >
                  Создать
                </button>
              </div>
            </form>
          )}

          <div className="flex-1 overflow-y-auto py-1.5">
            {files.map((file) => {
              const isActive = file.path === activeFilePath;
              const fileName = file.path.split('/').pop() || file.path;
              const dirName = file.path.includes('/')
                ? file.path.slice(0, file.path.lastIndexOf('/'))
                : '';

              return (
                <div
                  key={file.path}
                  className={`group flex items-center justify-between gap-2 px-3 py-2 text-xs transition-colors ${
                    isActive
                      ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 font-medium'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100/80 dark:hover:bg-slate-800/50'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => onSelectFile(file.path)}
                    className="flex items-start gap-2 min-w-0 flex-1 text-left cursor-pointer"
                  >
                    {file.language === 'kotlin' ? (
                      <FileCode2 className="w-3.5 h-3.5 mt-0.5 text-emerald-500 shrink-0" />
                    ) : (
                      <FileText className="w-3.5 h-3.5 mt-0.5 text-slate-400 shrink-0" />
                    )}
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <span className="truncate font-mono">{fileName}</span>
                        {file.modified && (
                          <span className="text-[10px] text-amber-500 font-semibold" title="Изменен">
                            ●
                          </span>
                        )}
                      </div>
                      {dirName && (
                        <div className="text-[11px] text-slate-400 dark:text-slate-500 truncate">
                          {dirName}
                        </div>
                      )}
                    </div>
                  </button>

                  {files.length > 1 && (
                    <button
                      type="button"
                      onClick={() => onDeleteFile(file.path)}
                      title="Удалить файл"
                      className="opacity-0 group-hover:opacity-100 p-1 rounded text-slate-400 hover:text-red-500 transition-opacity cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </>
      ) : (
        /* Ресурсы Tab */
        <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
          <div className="p-2 border-b border-slate-200 dark:border-slate-800/90 space-y-1 shrink-0">
            {RESOURCE_FILES_META.map((meta) => {
              const found = files.find((f) => getResourceKindFromPath(f.path) === meta.kind);
              const count = parseAndroidResourcesXml(
                found?.content ?? DEFAULT_RESOURCE_XML[meta.kind],
                meta.kind
              ).length;
              const isSelected = effectiveResKind === meta.kind;

              return (
                <button
                  key={meta.kind}
                  type="button"
                  onClick={() => handlePickResource(meta.kind)}
                  className={`w-full px-2.5 py-2 rounded-lg text-xs flex items-center justify-between gap-2 transition-colors cursor-pointer ${
                    isSelected
                      ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 font-medium'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/50'
                  }`}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    {meta.kind === 'colors' ? (
                      <Palette className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    ) : meta.kind === 'dimens' ? (
                      <Ruler className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    ) : (
                      <TypeIcon className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                    )}
                    <span className="font-mono truncate">{meta.filename}</span>
                  </div>
                  <span className="text-[11px] font-mono tabular-nums text-slate-500 dark:text-slate-400 shrink-0">
                    {count}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="px-3 py-2 border-b border-slate-200 dark:border-slate-800/80 flex items-center justify-between gap-2 text-[11px] text-slate-500 dark:text-slate-400 shrink-0">
            <span>Ключи и значения</span>
            <button
              type="button"
              onClick={() => handlePickResource(effectiveResKind)}
              className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400 hover:underline font-medium cursor-pointer"
            >
              <Table2 className="w-3 h-3" />
              <span>Таблица</span>
            </button>
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-slate-200 dark:divide-slate-800/70">
            {resourcePreviewEntries.map((entry) => (
              <button
                key={entry.id}
                type="button"
                onClick={() => handlePickResource(effectiveResKind)}
                className="w-full px-3 py-2 text-left hover:bg-slate-100/70 dark:hover:bg-slate-800/40 transition-colors cursor-pointer"
              >
                <div className="font-mono text-[11px] font-medium text-slate-800 dark:text-slate-200 truncate">
                  {entry.name}
                </div>
                <div className="mt-0.5 flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 truncate">
                  {effectiveResKind === 'colors' && (
                    <span
                      className="w-2.5 h-2.5 rounded-xs border border-slate-300 dark:border-slate-600 shrink-0"
                      style={{ backgroundColor: toHexColorPickerValue(entry.value) }}
                    />
                  )}
                  <span className={effectiveResKind !== 'strings' ? 'font-mono tabular-nums truncate' : 'truncate'}>
                    {entry.value}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Connected GitHub summary */}
      <div className="p-3 border-t border-slate-200 dark:border-slate-800/90 bg-slate-50/70 dark:bg-[#0B0F17]/60">
        <div className="flex items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-1.5 min-w-0 text-slate-700 dark:text-slate-300">
            <GitBranch className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span className="truncate font-medium">
              {connectedRepo ? `${connectedRepo.owner}/${connectedRepo.repo}` : 'Локальный проект'}
            </span>
          </div>
          <button
            type="button"
            onClick={onOpenGitHub}
            className="inline-flex items-center gap-1 text-xs font-medium text-emerald-600 dark:text-emerald-400 hover:underline whitespace-nowrap shrink-0 cursor-pointer"
          >
            <RefreshCw className="w-3 h-3" />
            <span>GitHub</span>
          </button>
        </div>
        <div className="mt-1 text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1.5 truncate">
          <span>{connectedRepo ? `Ветка ${connectedRepo.branch}` : 'Не привязан к репозиторию'}</span>
          <span aria-hidden="true">·</span>
          <span className="tabular-nums">{files.length} файл.</span>
        </div>
      </div>
    </aside>
  );
};

