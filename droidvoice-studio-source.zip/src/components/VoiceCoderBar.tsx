import React, { useEffect, useRef, useState } from 'react';
import {
  Mic,
  MicOff,
  Wand2,
  Loader2,
  Sun,
  Moon,
  SlidersHorizontal,
  ChevronRight,
} from 'lucide-react';
import { ProjectConfig } from '../types';

interface SpeechRecognitionEventLike {
  resultIndex: number;
  results: ArrayLike<{
    isFinal: boolean;
    0: { transcript: string };
  }>;
}

interface SpeechRecognitionLike {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((ev: SpeechRecognitionEventLike) => void) | null;
  onerror: ((ev: { error: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
}

interface VoiceCoderBarProps {
  activeFilePath: string;
  config: ProjectConfig;
  onChangeBuildType: (buildType: 'debug' | 'release') => void;
  onApplyVoiceCommand: (command: string) => Promise<void>;
  isGeneratingCode: boolean;
  isDark: boolean;
  onToggleTheme: () => void;
  onOpenProjectSettings: () => void;
  lastVoiceSummary: string | null;
}

const QUICK_VOICE_PROMPTS = [
  'Добавить карточку статистики с прогресс-баром',
  'Добавить кнопку экспорта заметок с Log.i',
  'Изменить заголовок TopAppBar на Voice Droid',
];

export const VoiceCoderBar: React.FC<VoiceCoderBarProps> = ({
  activeFilePath,
  config,
  onChangeBuildType,
  onApplyVoiceCommand,
  isGeneratingCode,
  isDark,
  onToggleTheme,
  onOpenProjectSettings,
  lastVoiceSummary,
}) => {
  const [command, setCommand] = useState('');
  const [voiceLang, setVoiceLang] = useState<'ru-RU' | 'en-US'>('ru-RU');
  const [isRecording, setIsRecording] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [voiceError, setVoiceError] = useState<string | null>(null);

  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  useEffect(() => {
    return () => {
      recognitionRef.current?.stop();
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
    };
  }, []);

  const startAudioFallbackRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      audioChunksRef.current = [];
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };
      recorder.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(audioChunksRef.current, { type: recorder.mimeType || 'audio/webm' });
        if (blob.size === 0) return;

        setIsTranscribing(true);
        setVoiceError(null);
        try {
          const base64 = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => {
              const result = String(reader.result || '');
              resolve(result.split(',')[1] || '');
            };
            reader.onerror = () => reject(new Error('Не удалось прочитать аудио'));
            reader.readAsDataURL(blob);
          });

          const resp = await fetch('/api/voice/transcribe', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              audioBase64: base64,
              mimeType: blob.type || 'audio/webm',
              language: voiceLang,
            }),
          });
          const data = (await resp.json()) as { transcript?: string; error?: string };
          if (!resp.ok) {
            throw new Error(data.error || 'Ошибка распознавания речи');
          }
          if (data.transcript) {
            setCommand((prev) => (prev ? `${prev} ${data.transcript}` : data.transcript!));
          }
        } catch (err: unknown) {
          setVoiceError(err instanceof Error ? err.message : 'Ошибка транскрибации');
        } finally {
          setIsTranscribing(false);
        }
      };

      mediaRecorderRef.current = recorder;
      recorder.start();
      setIsRecording(true);
      setVoiceError(null);
    } catch {
      setVoiceError('Нет доступа к микрофону. Проверьте разрешения браузера или введите команду текстом.');
      setIsRecording(false);
    }
  };

  const toggleVoiceInput = async () => {
    if (isRecording) {
      recognitionRef.current?.stop();
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
      setIsRecording(false);
      return;
    }

    setVoiceError(null);
    const SpeechRecCtor =
      (window as unknown as Record<string, unknown>).SpeechRecognition ||
      (window as unknown as Record<string, unknown>).webkitSpeechRecognition;

    if (typeof SpeechRecCtor === 'function') {
      try {
        const rec = new (SpeechRecCtor as new () => SpeechRecognitionLike)();
        rec.lang = voiceLang;
        rec.continuous = true;
        rec.interimResults = true;

        const baseText = command.trim();
        let finalTranscript = '';

        rec.onresult = (event: SpeechRecognitionEventLike) => {
          let interim = '';
          for (let i = event.resultIndex; i < event.results.length; i++) {
            const text = event.results[i][0].transcript;
            if (event.results[i].isFinal) {
              finalTranscript += text + ' ';
            } else {
              interim += text;
            }
          }
          const combined = [baseText, finalTranscript.trim(), interim.trim()]
            .filter(Boolean)
            .join(' ');
          setCommand(combined);
        };

        rec.onerror = (ev) => {
          if (ev.error === 'not-allowed' || ev.error === 'service-not-allowed') {
            setVoiceError('Доступ к микрофону запрещен');
            setIsRecording(false);
          } else {
            // Fall back to MediaRecorder + Gemini transcription
            rec.stop();
            void startAudioFallbackRecording();
          }
        };

        rec.onend = () => {
          setIsRecording(false);
        };

        recognitionRef.current = rec;
        rec.start();
        setIsRecording(true);
        return;
      } catch {
        // Fallback below
      }
    }

    await startAudioFallbackRecording();
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!command.trim() || isGeneratingCode) return;
    if (isRecording) {
      recognitionRef.current?.stop();
      setIsRecording(false);
    }
    const text = command.trim();
    await onApplyVoiceCommand(text);
  };

  return (
    <section
      aria-label="Панель голосового ввода кода и конфигурации"
      className="border-b border-slate-200 dark:border-slate-800/90 bg-slate-50/80 dark:bg-[#111724] px-4 lg:px-6 py-2.5 shrink-0"
    >
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-3">
        {/* Voice-to-code form */}
        <form onSubmit={handleSubmit} className="flex-1 flex flex-wrap sm:flex-nowrap items-center gap-2 min-w-0">
          <button
            type="button"
            onClick={toggleVoiceInput}
            disabled={isTranscribing}
            aria-pressed={isRecording}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500 ${
              isRecording
                ? 'bg-red-600 hover:bg-red-500 text-white'
                : 'bg-white dark:bg-[#182132] border border-slate-300 dark:border-slate-700 text-slate-800 dark:text-slate-100 hover:border-emerald-500/60'
            }`}
          >
            {isRecording ? (
              <>
                <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
                <MicOff className="w-3.5 h-3.5" />
                <span>Стоп запись</span>
              </>
            ) : isTranscribing ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-500" />
                <span>Распознавание...</span>
              </>
            ) : (
              <>
                <Mic className="w-3.5 h-3.5 text-emerald-500" />
                <span>Голосовой ввод</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={() => setVoiceLang((l) => (l === 'ru-RU' ? 'en-US' : 'ru-RU'))}
            title="Язык диктовки"
            className="px-2.5 py-2 rounded-lg text-xs font-mono font-medium bg-white dark:bg-[#182132] border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white whitespace-nowrap shrink-0 cursor-pointer"
          >
            {voiceLang === 'ru-RU' ? 'RU' : 'EN'}
          </button>

          <div className="relative flex-1 min-w-[200px]">
            <input
              type="text"
              value={command}
              onChange={(e) => setCommand(e.target.value)}
              placeholder={`Голосовая команда для ${activeFilePath.split('/').pop()}...`}
              className="w-full px-3.5 py-2 rounded-lg text-xs sm:text-sm bg-white dark:bg-[#0B0F17] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <button
            type="submit"
            disabled={!command.trim() || isGeneratingCode}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-white disabled:opacity-40 transition-colors whitespace-nowrap shrink-0 cursor-pointer disabled:cursor-not-allowed"
          >
            {isGeneratingCode ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>Генерация...</span>
              </>
            ) : (
              <>
                <Wand2 className="w-3.5 h-3.5" />
                <span>Вставить код</span>
              </>
            )}
          </button>
        </form>

        {/* Secondary workspace controls */}
        <div className="flex items-center justify-between xl:justify-end gap-3 shrink-0">
          <div className="flex items-center gap-1 p-0.5 bg-slate-200/80 dark:bg-[#0B0F17] border border-slate-300 dark:border-slate-800 rounded-lg">
            <button
              type="button"
              onClick={() => onChangeBuildType('debug')}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                config.buildType === 'debug'
                  ? 'bg-white dark:bg-[#1A2233] text-slate-900 dark:text-slate-100 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              Debug APK
            </button>
            <button
              type="button"
              onClick={() => onChangeBuildType('release')}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                config.buildType === 'release'
                  ? 'bg-white dark:bg-[#1A2233] text-slate-900 dark:text-slate-100 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              Release APK
            </button>
          </div>

          <button
            type="button"
            onClick={onOpenProjectSettings}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            title="Параметры AndroidManifest и Gradle"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span className="font-mono tabular-nums">API {config.targetSdk}</span>
          </button>

          <button
            type="button"
            onClick={onToggleTheme}
            aria-label={isDark ? 'Включить светлую тему' : 'Включить темную тему'}
            className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-200/70 dark:hover:bg-slate-800 transition-colors shrink-0 cursor-pointer"
          >
            {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Quick voice templates & feedback */}
      <div className="mt-2 flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-slate-500 dark:text-slate-400">Примеры команд:</span>
          {QUICK_VOICE_PROMPTS.map((preset) => (
            <button
              key={preset}
              type="button"
              onClick={() => setCommand(preset)}
              className="inline-flex items-center gap-1 text-slate-600 dark:text-slate-300 hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors cursor-pointer whitespace-nowrap"
            >
              <ChevronRight className="w-3 h-3 text-slate-400" />
              <span>{preset}</span>
            </button>
          ))}
        </div>

        {voiceError && (
          <span className="text-red-600 dark:text-red-400 font-medium">{voiceError}</span>
        )}
        {!voiceError && lastVoiceSummary && (
          <span className="text-emerald-600 dark:text-emerald-400 truncate max-w-md">
            Применено: {lastVoiceSummary}
          </span>
        )}
      </div>
    </section>
  );
};
