import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  CheckCircle2,
  Copy,
  Download,
  FileArchive,
  Loader2,
  Search,
  Sparkles,
  Trash2,
  XCircle,
  AlertTriangle,
} from 'lucide-react';
import { BuildJob, LogcatEntry } from '../types';

interface BuildLogsPaneProps {
  buildJob: BuildJob;
  logcatEntries: LogcatEntry[];
  onClearLogcat: () => void;
  onJumpToDiagnostic: (file: string, line: number) => void;
  onFixDiagnosticsWithAi: () => void;
  isFixingAi: boolean;
}

type LogTab = 'all' | 'gradle' | 'errors' | 'logcat';

export const BuildLogsPane: React.FC<BuildLogsPaneProps> = ({
  buildJob,
  logcatEntries,
  onClearLogcat,
  onJumpToDiagnostic,
  onFixDiagnosticsWithAi,
  isFixingAi,
}) => {
  const [activeTab, setActiveTab] = useState<LogTab>('all');
  const [filterText, setFilterText] = useState('');
  const [copied, setCopied] = useState(false);
  const logEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }, [buildJob.logs.length, logcatEntries.length, activeTab]);

  const filteredBuildLogs = useMemo(() => {
    const q = filterText.trim().toLowerCase();
    return buildJob.logs.filter((entry) => {
      if (activeTab === 'errors' && entry.level !== 'error' && entry.level !== 'warn') {
        return false;
      }
      if (activeTab === 'gradle' && entry.source === 'system') {
        return false;
      }
      if (q && !entry.message.toLowerCase().includes(q) && !entry.source.toLowerCase().includes(q)) {
        return false;
      }
      return true;
    });
  }, [buildJob.logs, activeTab, filterText]);

  const filteredLogcat = useMemo(() => {
    const q = filterText.trim().toLowerCase();
    return logcatEntries.filter((entry) => {
      if (!q) return true;
      return (
        entry.message.toLowerCase().includes(q) ||
        entry.tag.toLowerCase().includes(q)
      );
    });
  }, [logcatEntries, filterText]);

  const handleCopyLogs = async () => {
    const text =
      activeTab === 'logcat'
        ? filteredLogcat.map((l) => `${l.timestamp} ${l.level}/${l.tag}: ${l.message}`).join('\n')
        : filteredBuildLogs.map((l) => `[${l.timestamp}] [${l.source}] ${l.message}`).join('\n');
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  };

  const isRunning =
    buildJob.status === 'queued' ||
    buildJob.status === 'compiling' ||
    buildJob.status === 'packaging';

  return (
    <section
      aria-label="Индикатор прогресса сборки и окно логов компиляции"
      className="border-t border-slate-200 dark:border-slate-800/90 bg-white dark:bg-[#0E131D] flex flex-col min-h-0 h-full"
    >
      {/* Progress & Artifact Header */}
      <div className="px-4 py-3 border-b border-slate-200 dark:border-slate-800/90 space-y-2.5 shrink-0">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            {isRunning && <Loader2 className="w-4 h-4 text-emerald-500 animate-spin shrink-0" />}
            {buildJob.status === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />}
            {buildJob.status === 'failed' && <XCircle className="w-4 h-4 text-red-500 shrink-0" />}
            <span className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate">
              {buildJob.stage}
            </span>
            <span className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400 shrink-0">
              {buildJob.progress}%
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            {buildJob.status === 'success' && buildJob.id && (
              <>
                <a
                  href={`/api/build/${buildJob.id}/apk`}
                  download={buildJob.apkFilename || 'app-debug.apk'}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white transition-colors whitespace-nowrap shrink-0"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Скачать APK</span>
                  {buildJob.apkSizeBytes && (
                    <span className="font-mono tabular-nums opacity-90">
                      ({(buildJob.apkSizeBytes / 1024).toFixed(1)} КБ)
                    </span>
                  )}
                </a>
                <a
                  href={`/api/build/${buildJob.id}/project.zip`}
                  download={`android-project-${buildJob.id}.zip`}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 transition-colors whitespace-nowrap shrink-0"
                >
                  <FileArchive className="w-3.5 h-3.5" />
                  <span>Проект (.zip)</span>
                </a>
              </>
            )}

            {buildJob.status === 'failed' && buildJob.diagnostics.length > 0 && (
              <button
                type="button"
                onClick={onFixDiagnosticsWithAi}
                disabled={isFixingAi}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-amber-600 hover:bg-amber-500 text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-50"
              >
                {isFixingAi ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Sparkles className="w-3.5 h-3.5" />
                )}
                <span>Исправить ошибку</span>
              </button>
            )}
          </div>
        </div>

        {/* Progress Bar */}
        <div
          role="progressbar"
          aria-valuenow={buildJob.progress}
          aria-valuemin={0}
          aria-valuemax={100}
          className="h-1.5 w-full rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden"
        >
          <div
            className={`h-full transition-all duration-300 ease-out ${
              buildJob.status === 'failed'
                ? 'bg-red-500'
                : buildJob.status === 'success'
                ? 'bg-emerald-500'
                : 'bg-emerald-500'
            }`}
            style={{ width: `${Math.max(buildJob.progress, buildJob.status === 'idle' ? 0 : 4)}%` }}
          />
        </div>

        {/* Artifact metadata line (unboxed) */}
        {buildJob.status === 'success' && buildJob.apkSha256 && (
          <div className="flex flex-wrap items-center gap-2 text-[11px] font-mono text-slate-500 dark:text-slate-400">
            <span>Файл: {buildJob.apkFilename}</span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">Время: {((buildJob.durationMs || 0) / 1000).toFixed(2)} с</span>
            <span aria-hidden="true">·</span>
            <span>SHA-256: {buildJob.apkSha256.slice(0, 16)}…</span>
          </div>
        )}
      </div>

      {/* Filter Toolbar */}
      <div className="px-4 py-2 border-b border-slate-200 dark:border-slate-800/80 flex flex-wrap items-center justify-between gap-2 bg-slate-50/70 dark:bg-[#111724] shrink-0">
        <div className="flex items-center gap-1 p-0.5 bg-slate-200/80 dark:bg-[#0B0F17] rounded-lg">
          {(
            [
              { id: 'all', label: 'Все логи' },
              { id: 'gradle', label: 'Сборка' },
              { id: 'errors', label: `Ошибки (${buildJob.diagnostics.length})` },
              { id: 'logcat', label: `Logcat (${logcatEntries.length})` },
            ] as Array<{ id: LogTab; label: string }>
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`px-2.5 py-1 rounded-md text-xs font-medium whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                activeTab === tab.id
                  ? 'bg-white dark:bg-[#1A2233] text-slate-900 dark:text-slate-100 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={filterText}
              onChange={(e) => setFilterText(e.target.value)}
              placeholder="Фильтр логов..."
              className="pl-8 pr-2.5 py-1 rounded-md text-xs bg-white dark:bg-[#0B0F17] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-emerald-500 w-40 sm:w-52"
            />
          </div>
          <button
            type="button"
            onClick={handleCopyLogs}
            className="p-1.5 rounded text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100 hover:bg-slate-200/70 dark:hover:bg-slate-800 cursor-pointer"
            title="Копировать логи"
          >
            {copied ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
          {activeTab === 'logcat' && (
            <button
              type="button"
              onClick={onClearLogcat}
              className="p-1.5 rounded text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100 hover:bg-slate-200/70 dark:hover:bg-slate-800 cursor-pointer"
              title="Очистить Logcat"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Log Stream Body */}
      <div className="flex-1 overflow-y-auto p-3 font-mono text-xs leading-relaxed bg-slate-50/40 dark:bg-[#090D14] space-y-1">
        {activeTab === 'logcat' ? (
          filteredLogcat.length === 0 ? (
            <div className="py-6 text-center text-slate-500 dark:text-slate-400 font-sans text-xs">
              Logcat пуст. Нажимайте кнопки внутри облачного эмулятора, чтобы увидеть системные логи Android.
            </div>
          ) : (
            filteredLogcat.map((entry) => (
              <div key={entry.id} className="flex items-start gap-2.5 px-2 py-0.5 rounded hover:bg-slate-200/50 dark:hover:bg-slate-800/40">
                <span className="text-slate-400 dark:text-slate-500 tabular-nums shrink-0">
                  {entry.timestamp}
                </span>
                <span
                  className={`font-semibold shrink-0 ${
                    entry.level === 'E'
                      ? 'text-red-500'
                      : entry.level === 'W'
                      ? 'text-amber-500'
                      : entry.level === 'I'
                      ? 'text-emerald-500'
                      : 'text-sky-500'
                  }`}
                >
                  {entry.level}/{entry.tag}
                </span>
                <span className="text-slate-800 dark:text-slate-200 break-all">{entry.message}</span>
              </div>
            ))
          )
        ) : filteredBuildLogs.length === 0 ? (
          <div className="py-6 text-center text-slate-500 dark:text-slate-400 font-sans text-xs">
            Нажмите «Собрать APK» в верхней панели, чтобы отправить код на удаленный сервер сборки.
          </div>
        ) : (
          filteredBuildLogs.map((entry) => (
            <div
              key={entry.id}
              className={`flex items-start gap-2.5 px-2 py-1 rounded ${
                entry.level === 'error'
                  ? 'bg-red-500/10 text-red-700 dark:text-red-300'
                  : entry.level === 'warn'
                  ? 'bg-amber-500/10 text-amber-700 dark:text-amber-300'
                  : entry.level === 'success'
                  ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300'
                  : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200/40 dark:hover:bg-slate-800/30'
              }`}
            >
              <span className="text-slate-400 dark:text-slate-500 tabular-nums shrink-0">
                {entry.timestamp}
              </span>
              <span className="text-slate-500 dark:text-slate-400 uppercase text-[10px] pt-0.5 w-14 shrink-0">
                {entry.source}
              </span>
              <div className="flex-1 min-w-0 break-words">
                {entry.level === 'warn' && <AlertTriangle className="w-3.5 h-3.5 inline mr-1.5 -mt-0.5" />}
                {entry.file && entry.line ? (
                  <button
                    type="button"
                    onClick={() => onJumpToDiagnostic(entry.file!, entry.line!)}
                    className="text-left underline decoration-dotted hover:opacity-80 cursor-pointer"
                  >
                    {entry.message}
                  </button>
                ) : (
                  <span>{entry.message}</span>
                )}
              </div>
            </div>
          ))
        )}
        <div ref={logEndRef} />
      </div>
    </section>
  );
};
