import React, { useMemo, useState } from 'react';
import { Code2, Plus, Search, Table2, Trash2 } from 'lucide-react';
import { ProjectFile } from '../types';
import {
  AndroidResourceEntry,
  parseAndroidResourcesXml,
  RESOURCE_FILES_META,
  ResourceKind,
  serializeAndroidResourcesXml,
  toHexColorPickerValue,
} from '../utils/androidResources';

interface ResourcesTableEditorProps {
  activeFile: ProjectFile;
  resourceKind: ResourceKind;
  onSelectResourceKind: (kind: ResourceKind) => void;
  onUpdateXmlContent: (path: string, xmlContent: string) => void;
  onSwitchToRawXml: () => void;
}

export const ResourcesTableEditor: React.FC<ResourcesTableEditorProps> = ({
  activeFile,
  resourceKind,
  onSelectResourceKind,
  onUpdateXmlContent,
  onSwitchToRawXml,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [newKey, setNewKey] = useState('');
  const [newValue, setNewValue] = useState('');

  const entries = useMemo(
    () => parseAndroidResourcesXml(activeFile.content, resourceKind),
    [activeFile.content, resourceKind]
  );

  const filteredEntries = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return entries;
    return entries.filter(
      (item) =>
        item.name.toLowerCase().includes(q) || item.value.toLowerCase().includes(q)
    );
  }, [entries, searchQuery]);

  const commitEntries = (nextEntries: AndroidResourceEntry[]) => {
    const nextXml = serializeAndroidResourcesXml(nextEntries, resourceKind);
    onUpdateXmlContent(activeFile.path, nextXml);
  };

  const handleUpdateRow = (indexInEntries: number, field: 'name' | 'value', val: string) => {
    const next = entries.map((item, idx) =>
      idx === indexInEntries ? { ...item, [field]: val } : item
    );
    commitEntries(next);
  };

  const handleDeleteRow = (indexInEntries: number) => {
    const next = entries.filter((_, idx) => idx !== indexInEntries);
    commitEntries(next);
  };

  const handleAddRow = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanedKey =
      newKey.trim().replace(/[^a-zA-Z0-9_]/g, '_') ||
      (resourceKind === 'colors'
        ? `color_${entries.length + 1}`
        : resourceKind === 'dimens'
        ? `dimen_${entries.length + 1}`
        : `string_${entries.length + 1}`);

    const defaultVal =
      newValue.trim() ||
      (resourceKind === 'colors'
        ? '#10B981'
        : resourceKind === 'dimens'
        ? '16dp'
        : 'Новое значение');

    const next: AndroidResourceEntry[] = [
      ...entries,
      {
        id: `${resourceKind}-${Date.now()}`,
        name: cleanedKey,
        value: defaultVal,
      },
    ];
    commitEntries(next);
    setNewKey('');
    setNewValue('');
  };

  const activeMeta = RESOURCE_FILES_META.find((m) => m.kind === resourceKind)!;

  return (
    <div className="flex-1 flex flex-col min-w-0 min-h-0 bg-white dark:bg-[#0B0F17]">
      {/* Resource File Switcher + Raw XML toggle */}
      <div className="h-11 px-3 border-b border-slate-200 dark:border-slate-800/90 bg-slate-50 dark:bg-[#0E131D] flex items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-1 p-0.5 bg-slate-200/80 dark:bg-[#0B0F17] border border-slate-300 dark:border-slate-800 rounded-lg overflow-x-auto no-scrollbar">
          {RESOURCE_FILES_META.map((meta) => {
            const active = meta.kind === resourceKind;
            return (
              <button
                key={meta.kind}
                type="button"
                onClick={() => onSelectResourceKind(meta.kind)}
                className={`px-2.5 py-1 rounded-md text-xs font-mono font-medium whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                  active
                    ? 'bg-white dark:bg-[#1A2233] text-slate-900 dark:text-slate-100 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                }`}
              >
                {meta.filename}
              </button>
            );
          })}
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <div className="flex items-center gap-1 p-0.5 bg-slate-200/80 dark:bg-[#0B0F17] border border-slate-300 dark:border-slate-800 rounded-lg">
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium bg-white dark:bg-[#1A2233] text-slate-900 dark:text-slate-100 shadow-xs whitespace-nowrap shrink-0">
              <Table2 className="w-3.5 h-3.5 text-emerald-500" />
              <span>Таблица</span>
            </span>
            <button
              type="button"
              onClick={onSwitchToRawXml}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Code2 className="w-3.5 h-3.5" />
              <span>XML-код</span>
            </button>
          </div>
        </div>
      </div>

      {/* Search & Add Row Bar */}
      <div className="px-4 py-3 border-b border-slate-200 dark:border-slate-800/80 bg-slate-50/50 dark:bg-[#111724] flex flex-col sm:flex-row sm:items-center justify-between gap-3 shrink-0">
        <div className="relative flex-1 max-w-xs">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={`Поиск в ${activeMeta.filename}...`}
            className="w-full pl-8 pr-3 py-1.5 rounded-lg text-xs bg-white dark:bg-[#0B0F17] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-emerald-500"
          />
        </div>

        <form onSubmit={handleAddRow} className="flex flex-wrap sm:flex-nowrap items-center gap-2">
          <input
            type="text"
            value={newKey}
            onChange={(e) => setNewKey(e.target.value)}
            placeholder="Имя (snake_case)"
            className="w-36 sm:w-40 px-2.5 py-1.5 rounded-lg text-xs font-mono bg-white dark:bg-[#0B0F17] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
          />
          <input
            type="text"
            value={newValue}
            onChange={(e) => setNewValue(e.target.value)}
            placeholder={
              resourceKind === 'colors'
                ? '#10B981'
                : resourceKind === 'dimens'
                ? '16dp'
                : 'Значение'
            }
            className="w-36 sm:w-44 px-2.5 py-1.5 rounded-lg text-xs font-mono bg-white dark:bg-[#0B0F17] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
          />
          <button
            type="submit"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Добавить</span>
          </button>
        </form>
      </div>

      {/* High-Density Resource Table */}
      <div className="flex-1 overflow-auto">
        {filteredEntries.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-500 dark:text-slate-400 space-y-2">
            <p>
              {entries.length === 0
                ? `Файл ${activeMeta.filename} пока не содержит ресурсов.`
                : 'По вашему запросу записи не найдены.'}
            </p>
          </div>
        ) : (
          <table className="w-full border-collapse text-left text-xs">
            <thead className="sticky top-0 z-10 bg-slate-100 dark:bg-[#131A26] border-b border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300">
              <tr>
                <th className="py-2.5 px-4 font-semibold w-[36%]">Имя ключа (`name`)</th>
                <th className="py-2.5 px-4 font-semibold">
                  {resourceKind === 'colors'
                    ? 'Цвет и HEX-код'
                    : resourceKind === 'dimens'
                    ? 'Размер (dp / sp)'
                    : 'Значение строки'}
                </th>
                <th className="py-2.5 px-3 font-semibold text-right w-16">Удалить</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800/80">
              {filteredEntries.map((entry) => {
                const realIdx = entries.findIndex((e) => e.id === entry.id);
                const numericDimen = parseFloat(entry.value);
                const barWidth =
                  resourceKind === 'dimens' && !Number.isNaN(numericDimen)
                    ? Math.min(100, Math.max(8, numericDimen * 2.5))
                    : 0;

                return (
                  <tr
                    key={entry.id}
                    className="h-10 hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors"
                  >
                    <td className="px-4 py-1.5 align-middle">
                      <input
                        type="text"
                        value={entry.name}
                        onChange={(e) => handleUpdateRow(realIdx, 'name', e.target.value)}
                        aria-label={`Имя ресурса ${entry.name}`}
                        className="w-full px-2 py-1 rounded font-mono text-xs bg-transparent hover:bg-white dark:hover:bg-[#0B0F17] focus:bg-white dark:focus:bg-[#0B0F17] border border-transparent focus:border-emerald-500 text-slate-900 dark:text-slate-100 focus:outline-none"
                      />
                    </td>

                    <td className="px-4 py-1.5 align-middle">
                      <div className="flex items-center gap-2.5">
                        {resourceKind === 'colors' && (
                          <input
                            type="color"
                            value={toHexColorPickerValue(entry.value)}
                            onChange={(e) =>
                              handleUpdateRow(realIdx, 'value', e.target.value.toUpperCase())
                            }
                            aria-label={`Палитра для ${entry.name}`}
                            className="w-7 h-7 rounded border border-slate-300 dark:border-slate-700 bg-transparent cursor-pointer shrink-0 p-0.5"
                          />
                        )}

                        <input
                          type="text"
                          value={entry.value}
                          onChange={(e) => handleUpdateRow(realIdx, 'value', e.target.value)}
                          aria-label={`Значение ресурса ${entry.name}`}
                          className={`flex-1 px-2 py-1 rounded text-xs bg-transparent hover:bg-white dark:hover:bg-[#0B0F17] focus:bg-white dark:focus:bg-[#0B0F17] border border-transparent focus:border-emerald-500 text-slate-900 dark:text-slate-100 focus:outline-none ${
                            resourceKind !== 'strings' ? 'font-mono tabular-nums' : ''
                          }`}
                        />

                        {resourceKind === 'dimens' && barWidth > 0 && (
                          <div
                            className="hidden sm:block w-24 h-1.5 rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden shrink-0"
                            title={entry.value}
                          >
                            <div
                              className="h-full bg-emerald-500"
                              style={{ width: `${barWidth}%` }}
                            />
                          </div>
                        )}
                      </div>
                    </td>

                    <td className="px-3 py-1.5 align-middle text-right">
                      <button
                        type="button"
                        onClick={() => handleDeleteRow(realIdx)}
                        title={`Удалить ${entry.name}`}
                        className="p-1.5 rounded text-slate-400 hover:text-red-500 hover:bg-red-500/10 transition-colors cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {/* Resource Status Footer */}
      <div className="h-7 px-4 border-t border-slate-200 dark:border-slate-800/90 bg-slate-50 dark:bg-[#0E131D] flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 shrink-0">
        <span className="font-mono truncate">{activeFile.path}</span>
        <div className="flex items-center gap-2 font-mono tabular-nums whitespace-nowrap shrink-0">
          <span>Записей: {entries.length}</span>
          <span aria-hidden="true">·</span>
          <span>XML-синхронизация активна</span>
        </div>
      </div>
    </div>
  );
};
