import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  Check,
  ChevronDown,
  ChevronUp,
  Copy,
  Loader2,
  Mic,
  MicOff,
  Search,
  Table2,
  Undo2,
  X,
} from 'lucide-react';
import { BuildDiagnostic, ProjectFile } from '../types';
import {
  normalizeVoiceSearchQuery,
  ProjectSearchMatch,
  searchProjectFiles,
} from '../utils/codeSearch';

interface SpeechRecognitionEventLike {
  resultIndex: number;
  results: ArrayLike<{
    isFinal: boolean;
    0: { transcript: string };
  }>;
}

interface SpeechRecognitionLike {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((ev: SpeechRecognitionEventLike) => void) | null;
  onerror: ((ev: { error: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
}

interface CodeEditorPaneProps {
  files: ProjectFile[];
  openTabs: string[];
  activeFilePath: string;
  onSelectTab: (path: string) => void;
  onCloseTab: (path: string) => void;
  onChangeContent: (path: string, newContent: string) => void;
  diagnostics: BuildDiagnostic[];
  jumpToLineRequest: { file: string; line: number; nonce: number } | null;
  canUndoVoice: boolean;
  onUndoVoice: () => void;
  onSwitchToTable?: () => void;
  onNavigateToMatch: (filePath: string, line: number) => void;
}

export const CodeEditorPane: React.FC<CodeEditorPaneProps> = ({
  files,
  openTabs,
  activeFilePath,
  onSelectTab,
  onCloseTab,
  onChangeContent,
  diagnostics,
  jumpToLineRequest,
  canUndoVoice,
  onUndoVoice,
  onSwitchToTable,
  onNavigateToMatch,
}) => {
  const activeFile = files.find((f) => f.path === activeFilePath) || files[0];
  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const gutterRef = useRef<HTMLDivElement | null>(null);
  const backdropRef = useRef<HTMLDivElement | null>(null);

  const [cursorPos, setCursorPos] = useState({ line: 1, col: 1 });
  const [copied, setCopied] = useState(false);

  // Project-wide text & voice search state
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeMatchIdx, setActiveMatchIdx] = useState(0);
  const [isVoiceSearching, setIsVoiceSearching] = useState(false);
  const [isTranscribingSearch, setIsTranscribingSearch] = useState(false);
  const [voiceSearchError, setVoiceSearchError] = useState<string | null>(null);
  const [searchLang, setSearchLang] = useState<'ru-RU' | 'en-US'>('ru-RU');

  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const lines = useMemo(() => (activeFile?.content || '').split('\n'), [activeFile?.content]);
  const fileDiagnostics = diagnostics.filter((d) => d.file === activeFile?.path);

  const allMatches = useMemo(() => {
    if (!searchOpen || !searchQuery.trim()) return [];
    const normalized = normalizeVoiceSearchQuery(searchQuery);
    const directMatches = normalized ? searchProjectFiles(files, normalized) : [];
    if (directMatches.length > 0) return directMatches;
    return searchProjectFiles(files, searchQuery.trim());
  }, [files, searchOpen, searchQuery]);

  const effectiveSearchTerm = useMemo(() => {
    if (!searchOpen || !searchQuery.trim()) return '';
    const normalized = normalizeVoiceSearchQuery(searchQuery);
    if (normalized && searchProjectFiles(files, normalized).length > 0) {
      return normalized;
    }
    return searchQuery.trim();
  }, [files, searchOpen, searchQuery]);

  const currentMatch: ProjectSearchMatch | undefined =
    allMatches.length > 0 ? allMatches[activeMatchIdx % allMatches.length] : undefined;

  useEffect(() => {
    return () => {
      recognitionRef.current?.stop();
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
    };
  }, []);

  useEffect(() => {
    if (allMatches.length === 0) {
      setActiveMatchIdx(0);
    } else if (activeMatchIdx >= allMatches.length) {
      setActiveMatchIdx(0);
    }
  }, [allMatches.length, activeMatchIdx]);

  useEffect(() => {
    if (!jumpToLineRequest || !activeFile || jumpToLineRequest.file !== activeFile.path) return;
    const ta = textareaRef.current;
    if (!ta) return;

    const targetLine = Math.max(1, jumpToLineRequest.line);
    const split = activeFile.content.split('\n');
    let offset = 0;
    for (let i = 0; i < Math.min(targetLine - 1, split.length); i++) {
      offset += split[i].length + 1;
    }
    ta.focus();
    ta.setSelectionRange(offset, offset + (split[targetLine - 1]?.length || 0));
    const approxLineHeight = 22;
    const scrollTop = Math.max(0, (targetLine - 4) * approxLineHeight);
    ta.scrollTop = scrollTop;
    if (gutterRef.current) gutterRef.current.scrollTop = scrollTop;
    if (backdropRef.current) backdropRef.current.scrollTop = scrollTop;
    setCursorPos({ line: targetLine, col: 1 });
  }, [jumpToLineRequest, activeFile]);

  const syncScroll = () => {
    const ta = textareaRef.current;
    if (!ta) return;
    if (gutterRef.current) gutterRef.current.scrollTop = ta.scrollTop;
    if (backdropRef.current) {
      backdropRef.current.scrollTop = ta.scrollTop;
      backdropRef.current.scrollLeft = ta.scrollLeft;
    }
  };

  const updateCursorStats = () => {
    const ta = textareaRef.current;
    if (!ta) return;
    const upToCursor = ta.value.slice(0, ta.selectionStart);
    const split = upToCursor.split('\n');
    setCursorPos({
      line: split.length,
      col: split[split.length - 1].length + 1,
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const ta = e.currentTarget;
      const start = ta.selectionStart;
      const end = ta.selectionEnd;
      const nextValue = ta.value.slice(0, start) + '    ' + ta.value.slice(end);
      onChangeContent(activeFile.path, nextValue);
      requestAnimationFrame(() => {
        ta.selectionStart = ta.selectionEnd = start + 4;
      });
    } else if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'f') {
      e.preventDefault();
      setSearchOpen((v) => !v);
    }
  };

  const handleCopy = async () => {
    if (!activeFile) return;
    await navigator.clipboard.writeText(activeFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  const jumpToMatchAt = (index: number, list: ProjectSearchMatch[] = allMatches) => {
    if (list.length === 0) return;
    const normalizedIdx = ((index % list.length) + list.length) % list.length;
    setActiveMatchIdx(normalizedIdx);
    const m = list[normalizedIdx];
    onNavigateToMatch(m.filePath, m.line);
  };

  const applySpokenSearchQuery = (spokenText: string) => {
    const cleaned = normalizeVoiceSearchQuery(spokenText);
    const queryToUse = cleaned || spokenText.trim();
    setSearchOpen(true);
    setSearchQuery(queryToUse);
    setActiveMatchIdx(0);
    const found = searchProjectFiles(files, queryToUse);
    if (found.length > 0) {
      onNavigateToMatch(found[0].filePath, found[0].line);
    }
  };

  const startVoiceSearchFallback = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      audioChunksRef.current = [];
      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunksRef.current.push(e.data);
      };
      recorder.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(audioChunksRef.current, { type: recorder.mimeType || 'audio/webm' });
        if (blob.size === 0) return;

        setIsTranscribingSearch(true);
        setVoiceSearchError(null);
        try {
          const base64 = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => {
              const result = String(reader.result || '');
              resolve(result.split(',')[1] || '');
            };
            reader.onerror = () => reject(new Error('Ошибка чтения аудио'));
            reader.readAsDataURL(blob);
          });

          const resp = await fetch('/api/voice/transcribe', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              audioBase64: base64,
              mimeType: blob.type || 'audio/webm',
              language: searchLang,
            }),
          });
          const data = (await resp.json()) as { transcript?: string; error?: string };
          if (!resp.ok) throw new Error(data.error || 'Ошибка распознавания');
          if (data.transcript) {
            applySpokenSearchQuery(data.transcript);
          }
        } catch (err: unknown) {
          setVoiceSearchError(err instanceof Error ? err.message : 'Ошибка голосового поиска');
        } finally {
          setIsTranscribingSearch(false);
        }
      };

      mediaRecorderRef.current = recorder;
      recorder.start();
      setIsVoiceSearching(true);
      setVoiceSearchError(null);
    } catch {
      setVoiceSearchError('Нет доступа к микрофону. Введите запрос в строку поиска.');
      setIsVoiceSearching(false);
    }
  };

  const toggleVoiceSearch = async () => {
    setSearchOpen(true);

    if (isVoiceSearching) {
      recognitionRef.current?.stop();
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
      setIsVoiceSearching(false);
      return;
    }

    setVoiceSearchError(null);
    const SpeechRecCtor =
      (window as unknown as Record<string, unknown>).SpeechRecognition ||
      (window as unknown as Record<string, unknown>).webkitSpeechRecognition;

    if (typeof SpeechRecCtor === 'function') {
      try {
        const rec = new (SpeechRecCtor as new () => SpeechRecognitionLike)();
        rec.lang = searchLang;
        rec.continuous = false;
        rec.interimResults = true;

        let latestTranscript = '';

        rec.onresult = (event: SpeechRecognitionEventLike) => {
          let combined = '';
          for (let i = 0; i < event.results.length; i++) {
            combined += event.results[i][0].transcript + ' ';
          }
          latestTranscript = combined.trim();
          const normalized = normalizeVoiceSearchQuery(latestTranscript);
          setSearchQuery(normalized || latestTranscript);
        };

        rec.onerror = (ev) => {
          if (ev.error === 'not-allowed' || ev.error === 'service-not-allowed') {
            setVoiceSearchError('Доступ к микрофону запрещен');
            setIsVoiceSearching(false);
          } else {
            rec.stop();
            void startVoiceSearchFallback();
          }
        };

        rec.onend = () => {
          setIsVoiceSearching(false);
          if (latestTranscript) {
            applySpokenSearchQuery(latestTranscript);
          }
        };

        recognitionRef.current = rec;
        rec.start();
        setIsVoiceSearching(true);
        return;
      } catch {
        // Fall back to MediaRecorder
      }
    }

    await startVoiceSearchFallback();
  };

  const renderHighlightedLine = (lineText: string, lineNumber: number) => {
    if (!effectiveSearchTerm) {
      return lineText.length > 0 ? lineText : ' ';
    }

    const lowerLine = lineText.toLowerCase();
    const lowerTerm = effectiveSearchTerm.toLowerCase();
    const segments: React.ReactNode[] = [];
    let cursor = 0;

    while (cursor <= lowerLine.length - lowerTerm.length) {
      const idx = lowerLine.indexOf(lowerTerm, cursor);
      if (idx === -1) break;

      if (idx > cursor) {
        segments.push(lineText.slice(cursor, idx));
      }

      const isCurrent =
        currentMatch &&
        currentMatch.filePath === activeFile?.path &&
        currentMatch.line === lineNumber &&
        currentMatch.matchStart === idx;

      segments.push(
        <mark
          key={`${lineNumber}-${idx}`}
          className={
            isCurrent
              ? 'bg-emerald-500/40 text-transparent rounded-xs ring-1 ring-emerald-400'
              : 'bg-amber-400/30 text-transparent rounded-xs'
          }
        >
          {lineText.slice(idx, idx + effectiveSearchTerm.length)}
        </mark>
      );
      cursor = idx + effectiveSearchTerm.length;
    }

    if (cursor < lineText.length) {
      segments.push(lineText.slice(cursor));
    }

    return segments.length > 0 ? segments : ' ';
  };

  if (!activeFile) {
    return (
      <div className="flex-1 flex items-center justify-center text-sm text-slate-500">
        Выберите или создайте файл в структуре проекта
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col min-w-0 min-h-0 bg-white dark:bg-[#0B0F17]">
      {/* Open Tabs Strip */}
      <div className="h-10 border-b border-slate-200 dark:border-slate-800/90 bg-slate-50 dark:bg-[#0E131D] flex items-center justify-between gap-2 px-2 shrink-0">
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar min-w-0">
          {openTabs.map((tabPath) => {
            const tabFile = files.find((f) => f.path === tabPath);
            if (!tabFile) return null;
            const isActive = tabPath === activeFile.path;
            const shortName = tabPath.split('/').pop() || tabPath;
            const hasError = diagnostics.some(
              (d) => d.file === tabPath && d.severity === 'error'
            );

            return (
              <div
                key={tabPath}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs whitespace-nowrap shrink-0 transition-colors ${
                  isActive
                    ? 'bg-white dark:bg-[#171F2E] text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700/80 font-medium'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
              >
                <button
                  type="button"
                  onClick={() => onSelectTab(tabPath)}
                  className="inline-flex items-center gap-1.5 font-mono cursor-pointer"
                >
                  <span className={hasError ? 'text-red-500' : ''}>{shortName}</span>
                  {tabFile.modified && <span className="text-amber-500">●</span>}
                </button>
                {openTabs.length > 1 && (
                  <button
                    type="button"
                    onClick={() => onCloseTab(tabPath)}
                    aria-label={`Закрыть ${shortName}`}
                    className="p-0.5 rounded hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer"
                  >
                    <X className="w-3 h-3" />
                  </button>
                )}
              </div>
            );
          })}
        </div>

        <div className="flex items-center gap-1 shrink-0">
          {onSwitchToTable && (
            <button
              type="button"
              onClick={onSwitchToTable}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded text-xs font-medium text-emerald-600 dark:text-emerald-400 hover:bg-emerald-500/10 whitespace-nowrap shrink-0 cursor-pointer"
              title="Открыть табличный редактор ресурсов"
            >
              <Table2 className="w-3.5 h-3.5" />
              <span>Таблица</span>
            </button>
          )}
          {canUndoVoice && (
            <button
              type="button"
              onClick={onUndoVoice}
              className="inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-medium text-amber-600 dark:text-amber-400 hover:bg-amber-500/10 whitespace-nowrap shrink-0 cursor-pointer"
              title="Отменить последнее голосовое изменение"
            >
              <Undo2 className="w-3.5 h-3.5" />
              <span>Отменить правку</span>
            </button>
          )}
          <button
            type="button"
            onClick={() => void toggleVoiceSearch()}
            disabled={isTranscribingSearch}
            aria-pressed={isVoiceSearching}
            title="Голосовой поиск по коду проекта"
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
              isVoiceSearching
                ? 'bg-red-600 text-white'
                : 'text-slate-600 dark:text-slate-300 hover:text-emerald-600 dark:hover:text-emerald-400 hover:bg-slate-200/70 dark:hover:bg-slate-800'
            }`}
          >
            {isVoiceSearching ? (
              <>
                <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                <MicOff className="w-3.5 h-3.5" />
                <span>Стоп</span>
              </>
            ) : isTranscribingSearch ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-500" />
                <span>Поиск…</span>
              </>
            ) : (
              <>
                <Mic className="w-3.5 h-3.5 text-emerald-500" />
                <span className="hidden sm:inline">Поиск голосом</span>
              </>
            )}
          </button>
          <button
            type="button"
            onClick={() => setSearchOpen((v) => !v)}
            className={`p-1.5 rounded cursor-pointer transition-colors ${
              searchOpen
                ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                : 'text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100 hover:bg-slate-200/70 dark:hover:bg-slate-800'
            }`}
            title="Поиск по проекту (Ctrl+F)"
          >
            <Search className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={handleCopy}
            className="p-1.5 rounded text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100 hover:bg-slate-200/70 dark:hover:bg-slate-800 cursor-pointer"
            title="Копировать код"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
          </button>
        </div>
      </div>

      {/* Project-wide Voice & Text Search Bar */}
      {searchOpen && (
        <div className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#111724] shrink-0">
          <div className="px-3 py-2 flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => void toggleVoiceSearch()}
              disabled={isTranscribingSearch}
              aria-label="Микрофон голосового поиска"
              className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer transition-colors ${
                isVoiceSearching
                  ? 'bg-red-600 text-white'
                  : 'bg-white dark:bg-[#0B0F17] border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:border-emerald-500'
              }`}
            >
              {isVoiceSearching ? (
                <MicOff className="w-3.5 h-3.5" />
              ) : isTranscribingSearch ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin text-emerald-500" />
              ) : (
                <Mic className="w-3.5 h-3.5 text-emerald-500" />
              )}
              <span>{isVoiceSearching ? 'Слушаю…' : 'Голосом'}</span>
            </button>

            <button
              type="button"
              onClick={() => setSearchLang((l) => (l === 'ru-RU' ? 'en-US' : 'ru-RU'))}
              title="Язык голосового поиска"
              className="px-2 py-1.5 rounded-md text-[11px] font-mono bg-white dark:bg-[#0B0F17] border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300 cursor-pointer shrink-0"
            >
              {searchLang === 'ru-RU' ? 'RU' : 'EN'}
            </button>

            <div className="relative flex-1 min-w-[180px]">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setActiveMatchIdx(0);
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    jumpToMatchAt(e.shiftKey ? activeMatchIdx - 1 : activeMatchIdx + 1);
                  }
                }}
                placeholder="Найти строку или функцию во всем проекте..."
                className="w-full pl-8 pr-3 py-1.5 rounded-md text-xs font-mono bg-white dark:bg-[#0B0F17] border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
                autoFocus
              />
            </div>

            <div className="flex items-center gap-1 text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400 shrink-0">
              <span>
                {allMatches.length > 0
                  ? `${(activeMatchIdx % allMatches.length) + 1} / ${allMatches.length}`
                  : '0 совп.'}
              </span>
              <button
                type="button"
                onClick={() => jumpToMatchAt(activeMatchIdx - 1)}
                disabled={allMatches.length === 0}
                aria-label="Предыдущее совпадение"
                className="p-1 rounded hover:bg-slate-200 dark:hover:bg-slate-800 disabled:opacity-40 cursor-pointer"
              >
                <ChevronUp className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => jumpToMatchAt(activeMatchIdx + 1)}
                disabled={allMatches.length === 0}
                aria-label="Следующее совпадение"
                className="p-1 rounded hover:bg-slate-200 dark:hover:bg-slate-800 disabled:opacity-40 cursor-pointer"
              >
                <ChevronDown className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => {
                  setSearchOpen(false);
                  setSearchQuery('');
                }}
                aria-label="Закрыть поиск"
                className="p-1 rounded text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {voiceSearchError && (
            <div className="px-3 pb-2 text-xs text-red-600 dark:text-red-400">
              {voiceSearchError}
            </div>
          )}

          {allMatches.length > 0 && (
            <div className="max-h-28 overflow-y-auto border-t border-slate-200 dark:border-slate-800/80 divide-y divide-slate-200/70 dark:divide-slate-800/60">
              {allMatches.slice(0, 25).map((match, idx) => {
                const isSelected = idx === activeMatchIdx % allMatches.length;
                return (
                  <button
                    key={match.id}
                    type="button"
                    onClick={() => jumpToMatchAt(idx)}
                    className={`w-full px-3 py-1.5 text-left text-xs flex items-center gap-2.5 transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-emerald-500/12 text-emerald-700 dark:text-emerald-300'
                        : 'text-slate-600 dark:text-slate-400 hover:bg-slate-200/50 dark:hover:bg-slate-800/40'
                    }`}
                  >
                    <span className="font-mono tabular-nums text-[11px] shrink-0 text-slate-500 dark:text-slate-400">
                      {match.fileName}:{match.line}
                    </span>
                    <span className="font-mono truncate">{match.lineText.trim()}</span>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Diagnostics Strip for current file */}
      {fileDiagnostics.length > 0 && (
        <div className="px-4 py-2 border-b border-red-200 dark:border-red-900/50 bg-red-50/70 dark:bg-red-950/20 flex flex-wrap items-center gap-3 text-xs text-red-700 dark:text-red-300 shrink-0">
          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
          {fileDiagnostics.slice(0, 2).map((d, i) => (
            <span key={i} className="font-mono">
              Строка {d.line}: {d.message}
            </span>
          ))}
        </div>
      )}

      {/* Code Area with synchronized line-highlight backdrop */}
      <div className="flex-1 flex min-h-0 overflow-hidden relative">
        <div
          ref={gutterRef}
          aria-hidden="true"
          className="w-12 py-3 pr-2.5 text-right select-none overflow-hidden bg-slate-50/60 dark:bg-[#0D121B] border-r border-slate-200 dark:border-slate-800/70 font-mono text-xs leading-[22px] text-slate-400 dark:text-slate-600 tabular-nums shrink-0"
        >
          {lines.map((_, idx) => {
            const lineNum = idx + 1;
            const hasErr = fileDiagnostics.some(
              (d) => d.line === lineNum && d.severity === 'error'
            );
            const isMatchedLine =
              Boolean(effectiveSearchTerm) &&
              allMatches.some(
                (m) => m.filePath === activeFile.path && m.line === lineNum
              );
            const isActiveMatchLine =
              currentMatch?.filePath === activeFile.path && currentMatch.line === lineNum;

            return (
              <div
                key={lineNum}
                className={
                  hasErr
                    ? 'text-red-500 font-semibold'
                    : isActiveMatchLine
                    ? 'text-emerald-500 font-bold'
                    : isMatchedLine
                    ? 'text-amber-500 font-semibold'
                    : ''
                }
              >
                {lineNum}
              </div>
            );
          })}
        </div>

        <div className="flex-1 relative min-w-0 min-h-0 overflow-hidden">
          {/* Synchronized highlight backdrop */}
          <div
            ref={backdropRef}
            aria-hidden="true"
            className="absolute inset-0 p-3 font-mono text-xs sm:text-[13px] leading-[22px] whitespace-pre overflow-hidden pointer-events-none select-none text-transparent"
          >
            {lines.map((lineText, idx) => {
              const lineNum = idx + 1;
              const isMatchedLine =
                Boolean(effectiveSearchTerm) &&
                allMatches.some(
                  (m) => m.filePath === activeFile.path && m.line === lineNum
                );
              const isActiveMatchLine =
                currentMatch?.filePath === activeFile.path && currentMatch.line === lineNum;

              return (
                <div
                  key={lineNum}
                  className={
                    isActiveMatchLine
                      ? 'bg-emerald-500/12'
                      : isMatchedLine
                      ? 'bg-amber-400/10'
                      : ''
                  }
                >
                  {renderHighlightedLine(lineText, lineNum)}
                </div>
              );
            })}
          </div>

          <textarea
            ref={textareaRef}
            value={activeFile.content}
            onChange={(e) => {
              onChangeContent(activeFile.path, e.target.value);
              updateCursorStats();
            }}
            onScroll={syncScroll}
            onKeyUp={updateCursorStats}
            onClick={updateCursorStats}
            onKeyDown={handleKeyDown}
            spellCheck={false}
            autoCapitalize="off"
            autoComplete="off"
            autoCorrect="off"
            aria-label={`Редактор кода ${activeFile.path}`}
            className="code-editor relative z-10 w-full h-full p-3 bg-transparent text-slate-900 dark:text-slate-100 caret-emerald-500 font-mono text-xs sm:text-[13px] leading-[22px] resize-none focus:outline-none overflow-auto whitespace-pre"
          />
        </div>
      </div>

      {/* Editor Status Metadata Line (Unboxed, zero pills) */}
      <div className="h-7 px-4 border-t border-slate-200 dark:border-slate-800/90 bg-slate-50 dark:bg-[#0E131D] flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 shrink-0">
        <span className="font-mono truncate">{activeFile.path}</span>
        <div className="flex items-center gap-2 font-mono tabular-nums whitespace-nowrap shrink-0">
          <span>Стр {cursorPos.line}, Стлб {cursorPos.col}</span>
          <span aria-hidden="true">·</span>
          <span>{lines.length} строк</span>
          <span aria-hidden="true">·</span>
          <span className="uppercase">{activeFile.language}</span>
        </div>
      </div>
    </div>
  );
};
