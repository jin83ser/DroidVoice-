import { ProjectConfig, ProjectFile } from '../types';

export const DEFAULT_PROJECT_CONFIG: ProjectConfig = {
  projectName: 'DroidVoice Notes',
  applicationId: 'com.droidvoice.notes',
  versionName: '1.2.0',
  versionCode: 12,
  minSdk: 26,
  targetSdk: 35,
  buildType: 'debug',
};

export const STARTER_PROJECT_FILES: ProjectFile[] = [
  {
    path: 'app/src/main/java/com/droidvoice/notes/MainActivity.kt',
    language: 'kotlin',
    content: `package com.droidvoice.notes

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i("MainActivity", "Инициализация DroidVoice Notes")
        setContent {
            DroidVoiceTheme {
                NotesDashboardScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotesDashboardScreen() {
    var tasksCount by remember { mutableStateOf(3) }
    var voiceSyncEnabled by remember { mutableStateOf(true) }
    var quickNote by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("DroidVoice Notes") }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    tasksCount += 1
                    Log.d("NotesUI", "Добавлена голосовая заметка #$tasksCount")
                }
            ) {
                Text("+")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Активные заметки: $tasksCount",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "Синхронизация через удаленный сервер сборки и GitHub",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            OutlinedTextField(
                value = quickNote,
                onValueChange = { quickNote = it },
                label = { Text("Текст заметки") },
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Авто-синхронизация с GitHub")
                Switch(
                    checked = voiceSyncEnabled,
                    onCheckedChange = {
                        voiceSyncEnabled = it
                        Log.i("SyncSwitch", "GitHub sync = $it")
                    }
                )
            }

            Button(
                onClick = {
                    tasksCount += 1
                    Log.i("NotesUI", "Создана запись: $quickNote")
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Добавить заметку")
            }

            OutlinedButton(
                onClick = {
                    tasksCount = 0
                    quickNote = ""
                    Log.w("NotesUI", "Список заметок очищен")
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Сбросить счетчик")
            }
        }
    }
}
`,
  },
  {
    path: 'app/src/main/java/com/droidvoice/notes/Theme.kt',
    language: 'kotlin',
    content: `package com.droidvoice.notes

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DroidColorScheme = darkColorScheme(
    primary = Color(0xFF10B981),
    secondary = Color(0xFF38BDF8),
    background = Color(0xFF0B0F17),
    surface = Color(0xFF131A26),
    onPrimary = Color(0xFF042F2E),
    onBackground = Color(0xFFF8FAFC),
    onSurface = Color(0xFFE2E8F0)
)

@Composable
fun DroidVoiceTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DroidColorScheme,
        content = content
    )
}
`,
  },
  {
    path: 'app/src/main/java/com/droidvoice/notes/RemoteBuildClient.kt',
    language: 'kotlin',
    content: `package com.droidvoice.notes

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

data class RemoteBuildStatus(
    val buildId: String,
    val progress: Int,
    val status: String,
    val apkDownloadUrl: String?
)

class RemoteBuildClient(private val serverBaseUrl: String) {
    suspend fun triggerBuild(sourceCode: String): Result<RemoteBuildStatus> =
        withContext(Dispatchers.IO) {
            try {
                val url = URL("$serverBaseUrl/api/build/start")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    setRequestProperty("Content-Type", "application/json")
                    doOutput = true
                }
                conn.outputStream.use { it.write(sourceCode.toByteArray()) }
                val code = conn.responseCode
                Log.d("RemoteBuildClient", "Server responded with HTTP $code")
                Result.success(
                    RemoteBuildStatus(
                        buildId = "build-001",
                        progress = 100,
                        status = "SUCCESS",
                        apkDownloadUrl = "$serverBaseUrl/api/build/build-001/apk"
                    )
                )
            } catch (e: Exception) {
                Log.e("RemoteBuildClient", "Build request failed", e)
                Result.failure(e)
            }
        }
}
`,
  },
  {
    path: 'app/build.gradle.kts',
    language: 'gradle',
    content: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.droidvoice.notes"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.droidvoice.notes"
        minSdk = 26
        targetSdk = 35
        versionCode = 12
        versionName = "1.2.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    buildFeatures {
        compose = true
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
}
`,
  },
  {
    path: 'app/src/main/AndroidManifest.xml',
    language: 'xml',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.droidvoice.notes">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.RECORD_AUDIO" />

    <application
        android:allowBackup="true"
        android:label="@string/app_name"
        android:supportsRtl="true"
        android:theme="@android:style/Theme.Material.NoActionBar">
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
`,
  },
  {
    path: 'app/src/main/res/values/strings.xml',
    language: 'xml',
    content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">DroidVoice Notes</string>
    <string name="voice_hint">Произнесите команду для генерации Kotlin кода</string>
    <string name="action_add_note">Добавить заметку</string>
    <string name="action_reset">Сбросить счетчик</string>
</resources>
`,
  },
  {
    path: 'app/src/main/res/values/colors.xml',
    language: 'xml',
    content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="brand_primary">#10B981</color>
    <color name="brand_secondary">#38BDF8</color>
    <color name="surface_dark">#0B0F17</color>
    <color name="card_surface">#131A26</color>
    <color name="text_primary">#F8FAFC</color>
    <color name="error_crimson">#EF4444</color>
</resources>
`,
  },
  {
    path: 'app/src/main/res/values/dimens.xml',
    language: 'xml',
    content: `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <dimen name="spacing_small">8dp</dimen>
    <dimen name="spacing_medium">16dp</dimen>
    <dimen name="spacing_large">24dp</dimen>
    <dimen name="card_corner_radius">14dp</dimen>
    <dimen name="title_text_size">18sp</dimen>
</resources>
`,
  },
];
