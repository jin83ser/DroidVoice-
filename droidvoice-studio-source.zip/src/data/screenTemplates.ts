import { ProjectFile } from '../types';

export interface ScreenTemplateDefinition {
  id: 'list' | 'auth' | 'analytics' | 'profile' | 'detail';
  title: string;
  description: string;
  defaultScreenName: string;
  componentsSummary: string;
}

export const SCREEN_TEMPLATES: ScreenTemplateDefinition[] = [
  {
    id: 'list',
    title: 'Список с поиском',
    description: 'Лента карточек с фильтрацией по строке поиска и плавающей кнопкой добавления.',
    defaultScreenName: 'ItemsListScreen',
    componentsSummary: 'TopAppBar · SearchBar · LazyColumn / RecyclerView · FAB',
  },
  {
    id: 'auth',
    title: 'Форма авторизации',
    description: 'Экран входа с проверкой email, скрытием пароля и индикатором загрузки.',
    defaultScreenName: 'AuthLoginScreen',
    componentsSummary: 'OutlinedTextField · PasswordToggle · Button · ProgressBar',
  },
  {
    id: 'analytics',
    title: 'Карточка с графиком',
    description: 'Панель аналитики с гистограммой Canvas, показателями и выбором периода.',
    defaultScreenName: 'AnalyticsChartScreen',
    componentsSummary: 'MaterialCardView · Canvas Chart · SegmentedFilter · Metrics',
  },
  {
    id: 'profile',
    title: 'Профиль и настройки',
    description: 'Карточка пользователя, статистика активности и переключатели параметров.',
    defaultScreenName: 'UserProfileScreen',
    componentsSummary: 'AvatarCard · Switch · PreferencesList · OutlinedButton',
  },
  {
    id: 'detail',
    title: 'Детальная карточка',
    description: 'Экран подробного просмотра с описанием, счетчиком и кнопкой подтверждения.',
    defaultScreenName: 'ItemDetailScreen',
    componentsSummary: 'HeaderCard · CounterControls · Description · BottomAction',
  },
];

export function normalizeScreenNames(rawName: string, fallback: string) {
  const cleaned = rawName.replace(/[^a-zA-Z0-9_]/g, '').trim();
  const base = cleaned.length >= 2 ? cleaned : fallback;
  const pascal = base.charAt(0).toUpperCase() + base.slice(1);
  const snake = pascal
    .replace(/([a-z0-9])([A-Z])/g, '$1_$2')
    .replace(/_+/g, '_')
    .toLowerCase();
  return { pascal, snake };
}

export function generateTemplateFiles(
  templateId: ScreenTemplateDefinition['id'],
  rawScreenName: string,
  applicationId: string
): ProjectFile[] {
  const tmpl = SCREEN_TEMPLATES.find((t) => t.id === templateId) || SCREEN_TEMPLATES[0];
  const { pascal, snake } = normalizeScreenNames(rawScreenName, tmpl.defaultScreenName);
  const pkgPath = applicationId.replace(/\./g, '/');

  const ktPath = `app/src/main/java/${pkgPath}/${pascal}.kt`;
  const xmlPath = `app/src/main/res/layout/layout_${snake}.xml`;

  let ktContent = '';
  let xmlContent = '';

  if (templateId === 'list') {
    ktContent = `package ${applicationId}

import android.util.Log
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class ListEntryItem(
    val id: Int,
    val title: String,
    val subtitle: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ${pascal}() {
    var searchQuery by remember { mutableStateOf("") }
    var itemsList by remember {
        mutableStateOf(
            listOf(
                ListEntryItem(1, "Сборка релизного APK", "Проверено на Pixel 8 Pro · API 35"),
                ListEntryItem(2, "Синхронизация с GitHub", "Ветка main актуальна"),
                ListEntryItem(3, "Голосовой ввод Compose", "Распознано 42 строки Kotlin")
            )
        )
    }

    val filtered = itemsList.filter {
        it.title.contains(searchQuery, ignoreCase = true) ||
            it.subtitle.contains(searchQuery, ignoreCase = true)
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Список задач") })
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    val nextId = itemsList.size + 1
                    itemsList = itemsList + ListEntryItem(
                        id = nextId,
                        title = "Новый элемент #$nextId",
                        subtitle = "Создано из шаблона списка"
                    )
                    Log.d("${pascal}", "Добавлен элемент #$nextId")
                }
            ) {
                Text("+")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Поиск по списку") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filtered, key = { it.id }) { item ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                Log.i("${pascal}", "Выбран: \${item.title}")
                            }
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(item.title, style = MaterialTheme.typography.titleMedium)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(item.subtitle, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}
`;

    xmlContent = `<?xml version="1.0" encoding="utf-8"?>
<androidx.coordinatorlayout.widget.CoordinatorLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent">

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:orientation="vertical"
        android:padding="16dp">

        <com.google.android.material.textfield.TextInputLayout
            android:id="@+id/searchInputLayout"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:hint="Поиск по списку">

            <com.google.android.material.textfield.TextInputEditText
                android:id="@+id/etSearch"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:inputType="text"
                android:maxLines="1" />
        </com.google.android.material.textfield.TextInputLayout>

        <androidx.recyclerview.widget.RecyclerView
            android:id="@+id/recyclerItems"
            android:layout_width="match_parent"
            android:layout_height="0dp"
            android:layout_weight="1"
            android:layout_marginTop="12dp"
            app:layoutManager="androidx.recyclerview.widget.LinearLayoutManager" />
    </LinearLayout>

    <com.google.android.material.floatingactionbutton.FloatingActionButton
        android:id="@+id/fabAddItem"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_gravity="bottom|end"
        android:layout_margin="16dp"
        android:contentDescription="Добавить элемент" />

</androidx.coordinatorlayout.widget.CoordinatorLayout>
`;
  } else if (templateId === 'auth') {
    ktContent = `package ${applicationId}

import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ${pascal}(
    onAuthSuccess: (String) -> Unit = {}
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var rememberMe by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Авторизация") })
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Вход в аккаунт",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "Введите учетные данные для синхронизации проекта",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            OutlinedTextField(
                value = email,
                onValueChange = {
                    email = it
                    errorMessage = null
                },
                label = { Text("Электронная почта") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = password,
                onValueChange = {
                    password = it
                    errorMessage = null
                },
                label = { Text("Пароль") },
                visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Показать пароль")
                Switch(
                    checked = showPassword,
                    onCheckedChange = { showPassword = it }
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Запомнить сессию")
                Switch(
                    checked = rememberMe,
                    onCheckedChange = { rememberMe = it }
                )
            }

            if (errorMessage != null) {
                Text(
                    text = errorMessage ?: "",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Button(
                onClick = {
                    if (!email.contains("@") || password.length < 6) {
                        errorMessage = "Укажите корректный email и пароль от 6 символов"
                        Log.w("${pascal}", "Ошибка валидации входа")
                    } else {
                        Log.i("${pascal}", "Успешный вход: $email")
                        onAuthSuccess(email)
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Войти")
            }

            OutlinedButton(
                onClick = {
                    email = ""
                    password = ""
                    errorMessage = null
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Очистить форму")
            }
        }
    }
}
`;

    xmlContent = `<?xml version="1.0" encoding="utf-8"?>
<ScrollView
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:fillViewport="true">

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="vertical"
        android:padding="24dp">

        <TextView
            android:id="@+id/tvAuthTitle"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="Вход в аккаунт"
            android:textSize="22sp"
            android:textStyle="bold" />

        <com.google.android.material.textfield.TextInputLayout
            android:id="@+id/tilEmail"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="20dp"
            android:hint="Электронная почта">

            <com.google.android.material.textfield.TextInputEditText
                android:id="@+id/etEmail"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:inputType="textEmailAddress" />
        </com.google.android.material.textfield.TextInputLayout>

        <com.google.android.material.textfield.TextInputLayout
            android:id="@+id/tilPassword"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="12dp"
            android:hint="Пароль"
            app:endIconMode="password_toggle">

            <com.google.android.material.textfield.TextInputEditText
                android:id="@+id/etPassword"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:inputType="textPassword" />
        </com.google.android.material.textfield.TextInputLayout>

        <com.google.android.material.materialswitch.MaterialSwitch
            android:id="@+id/switchRemember"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="12dp"
            android:checked="true"
            android:text="Запомнить сессию" />

        <com.google.android.material.button.MaterialButton
            android:id="@+id/btnLogin"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="20dp"
            android:text="Войти" />

        <ProgressBar
            android:id="@+id/progressAuth"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_gravity="center_horizontal"
            android:layout_marginTop="16dp"
            android:visibility="gone" />
    </LinearLayout>
</ScrollView>
`;
  } else if (templateId === 'analytics') {
    ktContent = `package ${applicationId}

import android.util.Log
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ${pascal}() {
    var selectedPeriodDays by remember { mutableStateOf(7) }
    val chartPoints = remember(selectedPeriodDays) {
        if (selectedPeriodDays == 7) listOf(42f, 68f, 54f, 89f, 76f, 94f, 82f)
        else listOf(35f, 48f, 60f, 52f, 74f, 81f, 90f, 68f, 85f, 96f)
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Аналитика сборок") })
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Успешность компиляций · \${chartPoints.average().toInt()}%",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "Период: последние $selectedPeriodDays дн.",
                        style = MaterialTheme.typography.bodySmall
                    )

                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp)
                    ) {
                        val barCount = chartPoints.size
                        val slotWidth = size.width / barCount
                        val barWidth = slotWidth * 0.56f
                        val maxVal = 100f

                        chartPoints.forEachIndexed { index, value ->
                            val ratio = (value / maxVal).coerceIn(0f, 1f)
                            val barHeight = size.height * ratio
                            val left = index * slotWidth + (slotWidth - barWidth) / 2f
                            drawRoundRect(
                                color = Color(0xFF10B981),
                                topLeft = Offset(left, size.height - barHeight),
                                size = Size(barWidth, barHeight),
                                cornerRadius = CornerRadius(8f, 8f)
                            )
                        }
                    }
                }
            }

            Button(
                onClick = {
                    selectedPeriodDays = if (selectedPeriodDays == 7) 30 else 7
                    Log.i("${pascal}", "Переключен период графика: $selectedPeriodDays дн.")
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Переключить период (7 / 30 дней)")
            }
        }
    }
}
`;

    xmlContent = `<?xml version="1.0" encoding="utf-8"?>
<LinearLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:padding="16dp">

    <com.google.android.material.card.MaterialCardView
        android:id="@+id/cardChart"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        app:cardCornerRadius="16dp"
        app:cardElevation="2dp">

        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:orientation="vertical"
            android:padding="16dp">

            <TextView
                android:id="@+id/tvMetricTitle"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:text="Успешность сборок: 84%"
                android:textSize="18sp"
                android:textStyle="bold" />

            <TextView
                android:id="@+id/tvMetricSubtitle"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_marginTop="4dp"
                android:text="Период: последние 7 дней"
                android:textSize="13sp" />

            <FrameLayout
                android:id="@+id/chartContainer"
                android:layout_width="match_parent"
                android:layout_height="180dp"
                android:layout_marginTop="16dp" />
        </LinearLayout>
    </com.google.android.material.card.MaterialCardView>

    <com.google.android.material.button.MaterialButton
        android:id="@+id/btnTogglePeriod"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="16dp"
        android:text="Переключить период (7 / 30 дней)" />

</LinearLayout>
`;
  } else if (templateId === 'profile') {
    ktContent = `package ${applicationId}

import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ${pascal}() {
    var notificationsEnabled by remember { mutableStateOf(true) }
    var autoBuildOnVoice by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Профиль разработчика") })
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Алексей Смирнов", style = MaterialTheme.typography.titleMedium)
                    Text("Android Engineer · GitHub Connected", style = MaterialTheme.typography.bodySmall)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Push-уведомления о сборке")
                Switch(
                    checked = notificationsEnabled,
                    onCheckedChange = {
                        notificationsEnabled = it
                        Log.i("${pascal}", "Уведомления = $it")
                    }
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Авто-сборка после голосовой правки")
                Switch(
                    checked = autoBuildOnVoice,
                    onCheckedChange = {
                        autoBuildOnVoice = it
                        Log.i("${pascal}", "Авто-сборка = $it")
                    }
                )
            }

            Button(
                onClick = { Log.i("${pascal}", "Настройки профиля сохранены") },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Сохранить настройки")
            }
        }
    }
}
`;

    xmlContent = `<?xml version="1.0" encoding="utf-8"?>
<ScrollView
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent">

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="vertical"
        android:padding="16dp">

        <com.google.android.material.card.MaterialCardView
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            app:cardCornerRadius="16dp">

            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:padding="16dp">

                <TextView
                    android:id="@+id/tvProfileName"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="Алексей Смирнов"
                    android:textSize="18sp"
                    android:textStyle="bold" />

                <TextView
                    android:id="@+id/tvProfileRole"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="4dp"
                    android:text="Android Engineer" />
            </LinearLayout>
        </com.google.android.material.card.MaterialCardView>

        <com.google.android.material.materialswitch.MaterialSwitch
            android:id="@+id/switchNotifications"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="16dp"
            android:checked="true"
            android:text="Push-уведомления о сборке" />

        <com.google.android.material.button.MaterialButton
            android:id="@+id/btnSaveProfile"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="16dp"
            android:text="Сохранить настройки" />
    </LinearLayout>
</ScrollView>
`;
  } else {
    ktContent = `package ${applicationId}

import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ${pascal}() {
    var quantity by remember { mutableStateOf(1) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Детали объекта") })
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Облачный модуль сборки #$quantity", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "Поддержка параллельной компиляции Gradle и автоматической подписи APK.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            Button(
                onClick = {
                    quantity += 1
                    Log.d("${pascal}", "Увеличено количество: $quantity")
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Добавить единицу")
            }

            OutlinedButton(
                onClick = {
                    quantity = 1
                    Log.i("${pascal}", "Количество сброшено")
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Сбросить выбор")
            }
        }
    }
}
`;

    xmlContent = `<?xml version="1.0" encoding="utf-8"?>
<androidx.core.widget.NestedScrollView
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent">

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="vertical"
        android:padding="16dp">

        <com.google.android.material.card.MaterialCardView
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            app:cardCornerRadius="16dp">

            <LinearLayout
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:orientation="vertical"
                android:padding="16dp">

                <TextView
                    android:id="@+id/tvDetailTitle"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="Облачный модуль сборки"
                    android:textSize="18sp"
                    android:textStyle="bold" />

                <TextView
                    android:id="@+id/tvDetailBody"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:layout_marginTop="8dp"
                    android:text="Поддержка параллельной компиляции Gradle и подписи APK." />
            </LinearLayout>
        </com.google.android.material.card.MaterialCardView>

        <com.google.android.material.button.MaterialButton
            android:id="@+id/btnPrimaryAction"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="16dp"
            android:text="Подтвердить действие" />
    </LinearLayout>
</androidx.core.widget.NestedScrollView>
`;
  }

  return [
    { path: ktPath, content: ktContent, language: 'kotlin', modified: true },
    { path: xmlPath, content: xmlContent, language: 'xml', modified: true },
  ];
}
